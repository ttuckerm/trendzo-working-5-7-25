/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        portfolio: {
          orange: {
            DEFAULT: "#f97316",
            50: "rgb(249 115 22 / 0.05)",
            100: "rgb(249 115 22 / 0.1)",
            200: "rgb(249 115 22 / 0.2)",
            300: "rgb(249 115 22 / 0.3)",
            400: "rgb(249 115 22 / 0.4)",
            500: "rgb(249 115 22 / 0.5)",
            600: "rgb(249 115 22 / 0.6)",
            700: "rgb(249 115 22 / 0.7)",
            800: "rgb(249 115 22 / 0.8)",
            900: "rgb(249 115 22 / 0.9)",
          },
          rose: {
            DEFAULT: "#e11d48",
            50: "rgb(225 29 72 / 0.05)",
            100: "rgb(225 29 72 / 0.1)",
            200: "rgb(225 29 72 / 0.2)",
            300: "rgb(225 29 72 / 0.3)",
            400: "rgb(225 29 72 / 0.4)",
            500: "rgb(225 29 72 / 0.5)",
            600: "rgb(225 29 72 / 0.6)",
            700: "rgb(225 29 72 / 0.7)",
            800: "rgb(225 29 72 / 0.8)",
            900: "rgb(225 29 72 / 0.9)",
          },
          green: {
            DEFAULT: "#22c55e",
            50: "rgb(34 197 94 / 0.05)",
            100: "rgb(34 197 94 / 0.1)",
            200: "rgb(34 197 94 / 0.2)",
            300: "rgb(34 197 94 / 0.3)",
            400: "rgb(34 197 94 / 0.4)",
            500: "rgb(34 197 94 / 0.5)",
          },
          gray: {
            900: "#111827",
            800: "#1f2937",
            700: "#374151",
            600: "#4b5563",
            500: "#6b7280",
            400: "#9ca3af",
            300: "#d1d5db",
          },
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: 0 },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: 0 },
        },
        "pulse-once": {
          "0%, 100%": { opacity: 1 },
          "50%": { opacity: 0.8 },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "pulse-once": "pulse-once 1s ease-in-out 1",
      },
      backgroundImage: {
        'portfolio-gradient': 'linear-gradient(to right, rgba(16, 185, 129, 0.1), rgba(236, 72, 153, 0.2))',
        'button-gradient': 'linear-gradient(to right, rgb(249, 115, 22), rgb(225, 29, 72))',
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} 