"use client"

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { useRouter, useSearchParams } from 'next/navigation'
import { useSubscription } from '@/lib/contexts/SubscriptionContext'
import { useAuth } from '@/lib/hooks/useAuth'
import { useEditor, EditorProvider } from '@/lib/contexts/EditorContext'
import { Template, TemplateSection } from '@/lib/types/template'
import { 
  Clock, 
  Play, 
  Settings, 
  Save, 
  Share2, 
  Trash2, 
  Zap, 
  Download, 
  ChevronDown, 
  Plus, 
  Pencil,
  MessageSquare,
  TrendingUp,
  AlertCircle,
  ArrowLeft,
  Move,
  XCircle,
  Loader2,
  Check,
  AlertTriangle,
  Mail
} from 'lucide-react'
import LoadingFallback from '@/components/ui/LoadingFallback'
import Link from 'next/link'
import TemplateRemixer from '@/components/templates/TemplateRemixer'

// Main editor component wrapped with provider
export default function EditorPage() {
  return (
    <EditorProvider>
      <EditorContent />
    </EditorProvider>
  )
}

// Editor content using the editor context
function EditorContent() {
  console.log('EditorContent rendering - START');
  
  const router = useRouter()
  const searchParams = useSearchParams()
  const templateId = searchParams.get('id')
  const editorMode = searchParams.get('mode')
  // Get source parameter for tracking
  const source = searchParams.get('source')
  const campaign = searchParams.get('campaign')
  
  console.log('Template ID from URL:', templateId);
  console.log('Editor Mode:', editorMode);
  console.log('Source:', source);
  
  // Create a local state for the template initialization status
  const [isInitialized, setIsInitialized] = useState(false);
  // Show loading state - limit loading state duration to prevent infinite spinner
  const [showLoading, setShowLoading] = useState(true);
  // Emergency backup UI - render if we've waited too long
  const [needsFallbackUI, setNeedsFallbackUI] = useState(false);
  // Track if remixer panel is visible
  const [showRemixer, setShowRemixer] = useState(false);
  
  const { user } = useAuth()
  const { canAccess, isLoading: isSubscriptionLoading } = useSubscription()
  console.log('Auth state:', { isAuthenticated: !!user, isSubscriptionLoading });
  
  const {
    template,
    selectedSectionId,
    setSelectedSectionId,
    selectedSection,
    isLoading,
    isError,
    errorMessage,
    isDirty,
    isSaving,
    isGeneratingAI,
    isExporting,
    isPublishing,
    
    // Actions
    loadTemplate,
    createTemplate,
    saveTemplate,
    addSection,
    updateSection,
    deleteSection,
    updateTextOverlay,
    generateAIScript,
    publishTemplate,
    exportTemplate,
    updateTemplateProperty
  } = useEditor()

  console.log('Editor state:', { 
    hasTemplate: !!template, 
    selectedSectionId, 
    isLoading, 
    isError, 
    isInitialized 
  });

  // Check if the template came from a newsletter
  const isFromNewsletter = source === 'newsletter';
  
  // Track source attribution when template is loaded
  useEffect(() => {
    // Only run this if template has been loaded and we have a source
    if (template && source && !isLoading) {
      // Track the source attribution
      const trackSourceAttribution = async () => {
        try {
          // Track template usage by source
          await fetch('/api/analytics/track-template-usage', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              templateId: template.id,
              source,
              campaign,
              action: 'open_editor',
              userId: user?.uid || 'anonymous'
            }),
          });
          
          console.log('Tracked template source attribution:', { source, campaign });
        } catch (error) {
          console.error('Error tracking template source:', error);
        }
      };
      
      trackSourceAttribution();
    }
  }, [template, source, campaign, isLoading, user]);
  
  // Display newsletter banner for templates opened from newsletter
  const [showNewsletterBanner, setShowNewsletterBanner] = useState(isFromNewsletter);
  
  // Close the newsletter banner
  const closeNewsletterBanner = () => {
    setShowNewsletterBanner(false);
  };

  // Track template save when the user saves a template from newsletter
  const handleSaveWithTracking = async () => {
    try {
      // First save the template
      await saveTemplate();
      
      // If from newsletter, also track the save action for analytics
      if (isFromNewsletter && template) {
        await fetch('/api/analytics/track-template-usage', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            templateId: template.id,
            source,
            campaign,
            action: 'save_template',
            userId: user?.uid || 'anonymous'
          }),
        });
        console.log('Tracked newsletter template save:', { source, campaign });
      }
    } catch (error) {
      console.error('Error saving template with tracking:', error);
    }
  };

  // Template edit history tracking for analytics
  const trackTemplateEdit = async (action: string) => {
    if (!template || !isFromNewsletter) return;
    
    try {
      await fetch('/api/analytics/track-template-usage', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          templateId: template.id,
          source,
          campaign,
          action,
          userId: user?.uid || 'anonymous'
        }),
      });
      console.log(`Tracked template ${action}:`, { source, campaign });
    } catch (error) {
      console.error(`Error tracking template ${action}:`, error);
    }
  };

  // Handle export with tracking
  const handleExportWithTracking = async () => {
    await exportTemplate();
    if (isFromNewsletter) {
      trackTemplateEdit('template_exported');
    }
  };

  // Handle publish with tracking
  const handlePublishWithTracking = async () => {
    await publishTemplate();
    if (isFromNewsletter) {
      trackTemplateEdit('template_published');
    }
  };
  
  // Remove the redirect to allow access without authentication
  // Instead, we'll show a message for non-authenticated users
  const isAuthenticated = !!user
  
  // Check if we're in remix mode and user has premium access
  const isRemixMode = editorMode === 'remix'
  const hasPremiumAccess = canAccess('premium')
  
  // Show the remixer panel if in remix mode and user has premium access
  useEffect(() => {
    if (isRemixMode && hasPremiumAccess && template) {
      setShowRemixer(true)
    } else {
      setShowRemixer(false)
    }
  }, [isRemixMode, hasPremiumAccess, template])
  
  // Handle applying remixed template changes
  const handleApplyRemixChanges = (remixedTemplate: Template) => {
    if (!remixedTemplate || !template) return
    
    // Update sections with remixed ones
    remixedTemplate.sections.forEach((remixedSection: TemplateSection) => {
      const existingSection = template.sections.find(s => s.id === remixedSection.id)
      if (existingSection) {
        // Update existing section
        updateSection(existingSection.id, remixedSection)
      }
    })
    
    // Set template as modified
    setSelectedSectionId(null) // Reset selection to show changes
    
    // Hide remixer after applying changes
    setShowRemixer(false)
  }

  // Load existing template or create a new one - simplified approach
  useEffect(() => {
    console.log('Editor initialization effect running, initialized:', isInitialized, 'has template:', !!template);
    
    async function init() {
      console.log('Initializing editor...');
      
      try {
        if (templateId) {
          console.log('Loading template with ID:', templateId);
          await loadTemplate(templateId);
        } else {
          console.log('Creating new template');
          await createTemplate();
        }
        console.log('Setting initialized to true');
        setIsInitialized(true);
        console.log('Editor initialized successfully');
      } catch (error) {
        console.error('Failed to initialize editor:', error);
        // Try to create a template anyway
        try {
          console.log('Attempting to create fallback template');
          await createTemplate();
          setIsInitialized(true);
          console.log('Fallback template created successfully');
        } catch (innerError) {
          console.error('Failed to create fallback template:', innerError);
        }
      }
    }
    
    if (!isInitialized && !template) {
      console.log('Starting initialization process');
      init();
    } else {
      console.log('Skipping initialization, already initialized or template exists');
    }
  }, [templateId, isInitialized, template, loadTemplate, createTemplate]);

  // Loading timeout effect
  useEffect(() => {
    // If loading takes too long, stop showing the spinner after 5 seconds
    const timer = setTimeout(() => {
      setShowLoading(false);
    }, 5000);
    
    // If isLoading becomes false, update showLoading immediately
    if (!isLoading && !isSubscriptionLoading) {
      setShowLoading(false);
      clearTimeout(timer);
    }
    
    return () => clearTimeout(timer);
  }, [isLoading, isSubscriptionLoading]);
  
  // Fallback UI effect
  useEffect(() => {
    // If we're still not rendering after 8 seconds, show fallback UI
    const timer = setTimeout(() => {
      setNeedsFallbackUI(true);
    }, 8000);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Handle template name change
  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!template) return;
    console.log('Name change:', e.target.value);
    if (e.target.value !== template.name) {
      updateTemplateProperty('name', e.target.value);
    }
  }
  
  // Handle industry change
  const handleIndustryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    if (!template) return;
    console.log('Industry change:', e.target.value);
    if (e.target.value !== template.industry) {
      updateTemplateProperty('industry', e.target.value);
    }
  }
  
  // Handle category change
  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    if (!template) return;
    console.log('Category change:', e.target.value);
    if (e.target.value !== template.category) {
      updateTemplateProperty('category', e.target.value);
    }
  }
  
  // Handle text overlay changes
  const handleTextChange = (sectionId: string, overlayId: string, newText: string) => {
    console.log('Text change:', { sectionId, overlayId, newText });
    updateTextOverlay(sectionId, overlayId, { text: newText });
  }
  
  // Generate AI text using OpenAI
  const handleGenerateAI = async () => {
    if (!selectedSection) {
      console.error('No section selected for AI generation');
      return;
    }
    
    console.log('Generating AI script for section:', selectedSection.id);
    
    // In demo mode, allow AI generation without business tier
    if (!isAuthenticated || canAccess('business')) {
      try {
        await generateAIScript(selectedSection.id, {
          industry: template?.industry || 'General',
          style: 'engaging',
          objective: 'Convert viewers'
        });
      } catch (error) {
        console.error('Error generating AI script:', error);
      }
    }
  }
  
  // Handle delete template
  const handleDeleteTemplate = async () => {
    if (confirm('Are you sure you want to delete this template? This action cannot be undone.')) {
      console.log('Deleting template...');
      try {
        // In a real app, we would call an API to delete the template
        alert('Template deleted (demo)');
        router.push('/templates');
      } catch (error) {
        console.error('Error deleting template:', error);
      }
    }
  }
  
  // Add new section handler
  const handleAddSection = () => {
    console.log('Adding new section');
    addSection();
  }
  
  // Delete section handler
  const handleDeleteSection = (sectionId: string) => {
    if (confirm('Are you sure you want to delete this section?')) {
      console.log('Deleting section:', sectionId);
      deleteSection(sectionId);
    }
  }
  
  // Update section handler
  const handleUpdateSection = (sectionId: string, data: any) => {
    console.log('Updating section:', { sectionId, data });
    updateSection(sectionId, data);
  }
  
  // Calculate total duration
  const totalDuration = template?.sections.reduce((acc, section) => acc + section.duration, 0) || 0

  console.log('Rendering decision - showLoading:', showLoading, 'isLoading:', isLoading, 'isError:', isError, 'needsFallbackUI:', needsFallbackUI, 'hasTemplate:', !!template);
  
  if (showLoading && (isLoading || isSubscriptionLoading)) {
    console.log('Rendering loading state');
    return (
      <LoadingFallback 
        loadingMessage="Loading editor..." 
        fallbackMessage="The editor is taking longer than expected to load. This might be due to network issues or server load."
        timeoutMs={10000}
        showHomeLink={true}
        showBackLink={true}
        backHref="/dashboard-view/template-library"
      />
    )
  }
  
  // Show error state
  if (isError) {
    console.log('Rendering error state:', errorMessage);
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center">
        <div className="mb-6">
          <AlertTriangle className="h-12 w-12 text-red-500" />
        </div>
        <h2 className="text-2xl font-semibold text-gray-800 mb-2">
          Error Loading Editor
        </h2>
        <p className="text-gray-600 max-w-md mb-6">
          {errorMessage}
        </p>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => createTemplate()}
            className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 transition-colors"
          >
            Create New Template
          </button>
          <Link
            href="/"
            className="px-4 py-2 bg-gray-100 text-gray-800 rounded hover:bg-gray-200 transition-colors"
          >
            Go Back Home
          </Link>
        </div>
      </div>
    )
  }

  // If template is still null after loading and there's no error, create a default one
  if (!template && !isLoading && !isError) {
    console.log('Rendering template creation prompt');
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="text-center p-6 bg-blue-50 rounded-lg border border-blue-200 max-w-md">
          <h2 className="text-xl font-semibold text-blue-700 mb-4">Create a New Template</h2>
          <p className="text-blue-600 mb-6">Get started by creating a new TikTok template</p>
          <button 
            onClick={() => {
              console.log('Create template button clicked');
              createTemplate();
            }}
            className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Create Template
          </button>
        </div>
      </div>
    )
  }
  
  if (needsFallbackUI) {
    console.log('Rendering fallback UI');
    return (
      <div className="p-8">
        <h1 className="text-2xl font-bold mb-6">TikTok Template Editor (Fallback Mode)</h1>
        
        <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-md mb-6">
          <p className="text-yellow-800">
            The main editor is having trouble loading. Using simplified editor instead.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-4 rounded-md shadow-sm border border-gray-200">
            <h2 className="text-lg font-semibold mb-4">Template Settings</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Template Name</label>
                <input 
                  type="text"
                  value={template?.name || 'Untitled Template'}
                  onChange={(e) => updateTemplateProperty('name', e.target.value)}
                  className="w-full p-2 border rounded"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Industry</label>
                <select
                  value={template?.industry || 'E-commerce'}
                  onChange={(e) => updateTemplateProperty('industry', e.target.value)}
                  className="w-full p-2 border rounded"
                >
                  <option value="E-commerce">E-commerce</option>
                  <option value="Health & Fitness">Health & Fitness</option>
                  <option value="Beauty">Beauty</option>
                  <option value="Technology">Technology</option>
                  <option value="Food & Beverage">Food & Beverage</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Category</label>
                <select
                  value={template?.category || 'Sales'}
                  onChange={(e) => updateTemplateProperty('category', e.target.value)}
                  className="w-full p-2 border rounded"
                >
                  <option value="Sales">Sales</option>
                  <option value="Brand Awareness">Brand Awareness</option>
                  <option value="Product Launch">Product Launch</option>
                  <option value="Tutorial">Tutorial</option>
                </select>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-md shadow-sm border border-gray-200">
            <h2 className="text-lg font-semibold mb-4">Actions</h2>
            
            <div className="space-y-3">
              <button
                onClick={() => addSection()}
                className="w-full py-2 px-4 bg-blue-100 text-blue-800 rounded hover:bg-blue-200"
              >
                Add New Section
              </button>
              
              <button
                onClick={() => handleSaveWithTracking()}
                className="w-full py-2 px-4 bg-green-100 text-green-800 rounded hover:bg-green-200"
              >
                <Save size={16} className="mr-1.5" />
                Save
              </button>
              
              <button
                onClick={() => {
                  if (!template || !template.sections.length) return;
                  setSelectedSectionId(template.sections[0].id);
                }}
                className="w-full py-2 px-4 bg-purple-100 text-purple-800 rounded hover:bg-purple-200"
              >
                Select First Section
              </button>
            </div>
          </div>
          
          {selectedSection && (
            <div className="bg-white p-4 rounded-md shadow-sm border border-gray-200 md:col-span-2">
              <h2 className="text-lg font-semibold mb-4">Edit Section: {selectedSection.name}</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Section Name</label>
                  <input 
                    type="text"
                    value={selectedSection.name}
                    onChange={(e) => updateSection(selectedSection.id, { name: e.target.value })}
                    className="w-full p-2 border rounded"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Duration (seconds)</label>
                  <input 
                    type="number"
                    value={selectedSection.duration}
                    onChange={(e) => updateSection(selectedSection.id, { 
                      duration: Math.max(1, parseInt(e.target.value) || 1) 
                    })}
                    className="w-full p-2 border rounded"
                  />
                </div>
                
                {selectedSection.textOverlays.map(overlay => (
                  <div key={overlay.id}>
                    <label className="block text-sm font-medium mb-1">
                      {overlay.position.charAt(0).toUpperCase() + overlay.position.slice(1)} Text
                    </label>
                    <textarea
                      value={overlay.text}
                      onChange={(e) => updateTextOverlay(selectedSection.id, overlay.id, { text: e.target.value })}
                      className="w-full p-2 border rounded h-24"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  console.log('Rendering main editor UI');
  return (
    <div className="h-screen flex flex-col bg-gray-50 overflow-hidden">
      {/* Newsletter source banner */}
      {showNewsletterBanner && (
        <div className="bg-blue-50 border-b border-blue-200 p-2">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-100">
                  <Mail className="h-4 w-4 text-blue-600" />
                </span>
                <p className="ml-3 text-sm text-blue-700">
                  <span className="font-medium">Newsletter Template</span>
                  <span className="hidden md:inline"> - You've opened this template from {campaign ? campaign.replace(/-/g, ' ') : 'our newsletter'}</span>
                </p>
              </div>
              <button 
                onClick={closeNewsletterBanner}
                className="flex-shrink-0 rounded-md p-1 hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <span className="sr-only">Close</span>
                <XCircle className="h-5 w-5 text-blue-500" aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Editor header */}
      <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={() => router.push('/templates')}
            className="text-gray-600 hover:text-gray-800 mr-4"
            aria-label="Back to templates"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-xl font-semibold text-gray-800 mr-4">Template Editor</h1>
          <input
            type="text"
            value={template?.name || ''}
            onChange={handleNameChange}
            className="bg-gray-100 border border-gray-300 rounded-md px-3 py-1.5 text-sm"
            placeholder="Template name"
          />
          {isDirty && (
            <span className="text-xs text-amber-600 ml-2">(Unsaved changes)</span>
          )}
        </div>
        
        <div className="flex items-center space-x-3">
          {!isAuthenticated && (
            <div className="bg-amber-50 text-amber-800 px-3 py-1.5 rounded-md flex items-center text-sm mr-2">
              <AlertCircle size={16} className="mr-1.5" />
              Demo Mode
            </div>
          )}
          <button
            onClick={handleSaveWithTracking}
            className="w-full py-2 px-4 bg-green-100 text-green-800 rounded hover:bg-green-200"
          >
            <Save size={16} className="mr-1.5" />
            Save
          </button>
          
          <button
            onClick={handlePublishWithTracking}
            className="w-full py-2 px-4 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            <Share2 size={16} className="mr-1.5" />
            Publish
          </button>
        </div>
      </header>
      
      {/* Main Content - Three Column Layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Column - Template Structure */}
        <div className="w-1/4 bg-white border-r border-gray-200 flex flex-col">
          <div className="p-4 border-b border-gray-200">
            <h2 className="font-semibold text-gray-800 mb-1">Template Structure</h2>
            <p className="text-xs text-gray-500">Total Duration: {totalDuration}s</p>
          </div>
          
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {template?.sections.map(section => (
              <div 
                key={section.id} 
                className={`p-3 rounded-lg cursor-pointer transition-colors ${
                  selectedSectionId === section.id 
                    ? 'bg-blue-50 border border-blue-200' 
                    : 'bg-gray-100 hover:bg-gray-200 border border-gray-200'
                }`}
                onClick={() => setSelectedSectionId(section.id)}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center">
                    <Move size={14} className="text-gray-400 mr-2 cursor-move" />
                    <h3 className="font-medium text-gray-800">{section.name}</h3>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-gray-500 flex items-center">
                      <Clock size={12} className="mr-1" />
                      {section.duration}s
                    </span>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteSection(section.id);
                      }}
                      className="text-gray-400 hover:text-red-500"
                      aria-label="Delete section"
                    >
                      <XCircle size={14} />
                    </button>
                  </div>
                </div>
                <p className="text-xs text-gray-600 truncate">
                  {section.textOverlays[0]?.text || 'No text'}
                </p>
              </div>
            ))}
            
            <button 
              onClick={handleAddSection}
              className="w-full py-2 border border-dashed border-gray-300 rounded-lg text-gray-500 flex items-center justify-center hover:bg-gray-50 transition-colors"
              aria-label="Add new section"
            >
              <Plus size={16} className="mr-1" />
              Add Section
            </button>
          </div>
          
          {/* Text Overlays */}
          {selectedSection && (
            <div className="p-4 border-t border-gray-200">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold text-gray-800">Text Overlays</h2>
                <button
                  onClick={handleGenerateAI}
                  disabled={isGeneratingAI}
                  className={`flex items-center text-xs px-2 py-1 rounded ${
                    isGeneratingAI 
                      ? 'bg-gray-200 text-gray-500' 
                      : 'bg-purple-100 text-purple-700 hover:bg-purple-200'
                  } transition-colors`}
                >
                  {isGeneratingAI ? (
                    <Loader2 size={12} className="mr-1 animate-spin" />
                  ) : (
                    <Zap size={12} className="mr-1" />
                  )}
                  {isGeneratingAI ? 'Generating...' : 'AI Script'}
                </button>
              </div>
              
              <div className="space-y-3">
                {selectedSection.textOverlays.map(overlay => (
                  <div key={overlay.id} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-medium text-gray-600">
                        {overlay.position.charAt(0).toUpperCase() + overlay.position.slice(1)} Text
                      </label>
                      <span className="text-xs text-gray-500">{overlay.style}</span>
                    </div>
                    <textarea
                      value={overlay.text}
                      onChange={(e) => handleTextChange(selectedSection.id, overlay.id, e.target.value)}
                      className="w-full p-2 border border-gray-300 rounded-md text-sm resize-none"
                      rows={2}
                    />
                  </div>
                ))}
              </div>
              
              <div className="mt-4 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-gray-600">Section Name</label>
                </div>
                <input
                  type="text"
                  value={selectedSection.name}
                  onChange={(e) => handleUpdateSection(selectedSection.id, { name: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md text-sm"
                />
                
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-gray-600">Duration (seconds)</label>
                </div>
                <input
                  type="number"
                  min="1"
                  max="60"
                  value={selectedSection.duration}
                  onChange={(e) => handleUpdateSection(selectedSection.id, { duration: Number(e.target.value) })}
                  className="w-full p-2 border border-gray-300 rounded-md text-sm"
                />
              </div>
            </div>
          )}
        </div>
        
        {/* Middle Column - Preview Area */}
        <div className="w-2/4 flex flex-col items-center justify-center bg-gray-900 p-8">
          <div className="relative w-[280px] h-[500px] bg-black rounded-3xl overflow-hidden border-8 border-gray-800">
            {/* Mobile frame mockup */}
            <div className="absolute top-0 left-0 right-0 h-6 bg-gray-800 flex justify-center items-center z-10">
              <div className="w-16 h-1.5 bg-gray-600 rounded-full"></div>
            </div>
            
            {/* Content preview */}
            <div className="w-full h-full bg-gray-300 flex items-center justify-center relative">
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-gray-500 text-sm">Template preview</span>
              </div>
              
              {/* Text overlay preview */}
              {selectedSection && selectedSection.textOverlays.map(overlay => (
                <div 
                  key={overlay.id} 
                  className={`absolute w-full px-4 text-center ${
                    overlay.position === 'top' ? 'top-8' : 
                    overlay.position === 'middle' ? 'top-1/2 -translate-y-1/2' : 
                    'bottom-8'
                  }`}
                >
                  <div 
                    className={`
                      ${overlay.style === 'headline' ? 'text-xl font-bold' : 
                        overlay.style === 'quote' ? 'text-lg italic' : 
                        'text-sm font-medium'}
                      bg-black bg-opacity-50 text-white p-2 rounded
                    `}
                  >
                    {overlay.text}
                  </div>
                </div>
              ))}
              
              {/* Play button overlay */}
              <button className="absolute inset-0 m-auto w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-colors">
                <div className="bg-white rounded-full w-12 h-12 flex items-center justify-center">
                  <Play size={20} className="text-gray-800 ml-1" />
                </div>
              </button>
            </div>
          </div>
          
          <div className="mt-6 text-white text-center">
            <p className="text-sm mb-1">Selected Section: {selectedSection?.name}</p>
            <p className="text-xs text-gray-400">Duration: {selectedSection?.duration}s</p>
          </div>
          
          <div className="mt-6 flex space-x-2">
            <button className="px-3 py-1.5 bg-gray-700 text-white rounded-md text-sm flex items-center hover:bg-gray-600">
              <Play size={14} className="mr-1.5" /> Preview
            </button>
            <button className="px-3 py-1.5 bg-gray-700 text-white rounded-md text-sm flex items-center hover:bg-gray-600">
              <Pencil size={14} className="mr-1.5" /> Edit Styles
            </button>
          </div>
        </div>
        
        {/* Right Column - Settings */}
        <div className="w-1/4 bg-white border-l border-gray-200 flex flex-col">
          <div className="p-4 border-b border-gray-200">
            <h2 className="font-semibold text-gray-800">Template Settings</h2>
          </div>
          
          <div className="p-4 space-y-4 flex-1 overflow-y-auto">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Industry
              </label>
              <select
                value={template?.industry || ''}
                onChange={handleIndustryChange}
                className="w-full p-2 border border-gray-300 rounded-md bg-white"
              >
                <option value="E-commerce">E-commerce</option>
                <option value="Health & Fitness">Health & Fitness</option>
                <option value="Beauty">Beauty</option>
                <option value="Technology">Technology</option>
                <option value="Food & Beverage">Food & Beverage</option>
                <option value="Fashion">Fashion</option>
                <option value="Education">Education</option>
                <option value="Travel">Travel</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category
              </label>
              <select
                value={template?.category || ''}
                onChange={handleCategoryChange}
                className="w-full p-2 border border-gray-300 rounded-md bg-white"
              >
                <option value="Sales">Sales</option>
                <option value="Brand Awareness">Brand Awareness</option>
                <option value="Product Launch">Product Launch</option>
                <option value="Tutorial">Tutorial</option>
                <option value="Testimonial">Testimonial</option>
                <option value="Behind the Scenes">Behind the Scenes</option>
              </select>
            </div>
            
            {/* In demo mode, always show analytics */}
            {(!isAuthenticated || canAccess('premium') || canAccess('business')) && (
              <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
                <h3 className="text-sm font-medium text-gray-800 mb-2 flex items-center">
                  <TrendingUp size={16} className="mr-1.5" /> Analytics
                </h3>
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-white p-2 rounded border border-gray-200">
                    <p className="text-xs text-gray-500">Views</p>
                    <p className="font-medium">{template?.views.toLocaleString() || '0'}</p>
                  </div>
                  <div className="bg-white p-2 rounded border border-gray-200">
                    <p className="text-xs text-gray-500">Usage</p>
                    <p className="font-medium">{template?.usageCount || '0'} videos</p>
                  </div>
                </div>
              </div>
            )}
            
            {isAuthenticated && !canAccess('premium') && (
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                <p className="text-sm text-blue-800 mb-2">
                  Upgrade to Premium to view analytics data
                </p>
                <button className="w-full bg-blue-600 text-white text-sm font-medium py-1.5 rounded hover:bg-blue-700 transition-colors">
                  Upgrade Now
                </button>
              </div>
            )}
            
            {!isAuthenticated && (
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                <p className="text-sm text-blue-800 mb-2">
                  You're in demo mode. Sign in to save changes.
                </p>
                <button 
                  onClick={() => router.push('/auth')}
                  className="w-full bg-blue-600 text-white text-sm font-medium py-1.5 rounded hover:bg-blue-700 transition-colors"
                >
                  Sign In
                </button>
              </div>
            )}
          </div>
          
          <div className="p-4 border-t border-gray-200 space-y-3">
            <button
              onClick={handleExportWithTracking}
              className="w-full bg-gray-100 text-gray-800 py-2 rounded-md flex items-center justify-center hover:bg-gray-200 transition-colors"
            >
              {isExporting ? (
                <Loader2 size={16} className="mr-1.5 animate-spin" />
              ) : (
                <Download size={16} className="mr-1.5" />
              )}
              {isExporting ? 'Exporting...' : 'Export Template'}
            </button>
            
            <button 
              className="w-full border border-red-200 text-red-600 py-2 rounded-md flex items-center justify-center hover:bg-red-50 transition-colors"
              onClick={handleDeleteTemplate}
            >
              <Trash2 size={16} className="mr-1.5" />
              Delete Template
            </button>
          </div>
        </div>
      </div>

      {/* Remixer Panel */}
      {showRemixer && template && (
        <div className="mb-6 border border-blue-200 rounded-lg bg-blue-50 p-1">
          <div className="bg-white rounded-lg">
            <TemplateRemixer 
              template={template} 
              onApplyChanges={handleApplyRemixChanges} 
            />
          </div>
        </div>
      )}
    </div>
  )
} 