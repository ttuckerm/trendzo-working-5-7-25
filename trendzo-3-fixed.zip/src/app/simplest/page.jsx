export default function SimplestPage() {
  return (
    <html>
      <head>
        <title>Trendzo Dashboard</title>
      </head>
      <body>
        <h1>Trendzo Dashboard</h1>
        <p>This is the most basic dashboard view with no dependencies.</p>
        
        <h2>Statistics</h2>
        <ul>
          <li>Templates Created: 12</li>
          <li>Total Views: 8.5K</li>
          <li>Active Trends: 24</li>
          <li>Performance Score: 85%</li>
        </ul>
        
        <h2>Recent Templates</h2>
        <ol>
          <li>Product Showcase</li>
          <li>Dance Challenge</li>
          <li>Tutorial Format</li>
          <li>Trend Reaction</li>
          <li>Story Time Format</li>
        </ol>
        
        <p>This page intentionally uses no styling, JavaScript, or advanced features to ensure compatibility.</p>
      </body>
    </html>
  )
} 