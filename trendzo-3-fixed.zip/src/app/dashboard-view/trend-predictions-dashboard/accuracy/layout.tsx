'use client';

import React from 'react';

/**
 * Layout component for the Prediction Accuracy page
 */
export default function PredictionAccuracyLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
} 