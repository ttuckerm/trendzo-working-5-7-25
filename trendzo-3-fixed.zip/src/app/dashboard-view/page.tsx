'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { FileText, Eye, BarChart2, Users, PlusSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/unified-card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/ui-compatibility';
import { useComponentFix } from '@/lib/utils/component-fix';
import { resolveComponents, initializeComponentResolution } from '@/lib/utils/import-resolver';

// Initialize component resolution
if (typeof window !== 'undefined') {
  initializeComponentResolution();
}

// Resolve UI components to ensure they work correctly
const UIComponents = resolveComponents({
  Button,
  Card,
  CardContent,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
});

export default function DashboardViewPage() {
  const [activeTab, setActiveTab] = useState('overview');
  
  // Stats for the dashboard
  const stats = {
    templates: {
      count: 12,
      change: 8,
      period: 'Last 30 days'
    },
    views: {
      count: '8.6K',
      change: 15,
      period: 'Last 30 days'
    },
    engagement: {
      count: '4.7%',
      change: -2,
      period: 'Last 30 days'
    },
    followers: {
      count: '1.3K',
      change: 5,
      period: 'Last 30 days'
    }
  };

  // Recent templates
  const recentTemplates = [
    {
      id: '1',
      title: 'Product Showcase',
      views: 542,
      likes: 124,
      shares: 47,
      date: '2023-06-12'
    },
    {
      id: '2',
      title: 'Tutorial Format',
      views: 328,
      likes: 87,
      shares: 32,
      date: '2023-06-10'
    }
  ];

  useEffect(() => {
    // Add component fix for error handling
    const componentFixCleanup = useComponentFix();
    
    return () => {
      if (typeof componentFixCleanup === 'function') {
        componentFixCleanup();
      }
    };
  }, []);

  // Destructure UI components for usage
  const { 
    Button: ResolvedButton, 
    Card: ResolvedCard, 
    CardContent: ResolvedCardContent,
    Tabs: ResolvedTabs,
    TabsContent: ResolvedTabsContent,
    TabsList: ResolvedTabsList,
    TabsTrigger: ResolvedTabsTrigger
  } = UIComponents;

  return (
    <div className="container py-8 max-w-7xl mx-auto">
      {/* Dashboard Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8 space-y-4 md:space-y-0">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-gray-500 mt-1">Welcome to your Trendzo dashboard</p>
        </div>
        
        <ResolvedButton className="bg-blue-600 hover:bg-blue-700">
          <PlusSquare className="h-4 w-4 mr-2" />
          Create Template
        </ResolvedButton>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Total Templates */}
        <ResolvedCard>
          <ResolvedCardContent className="p-6">
            <div className="flex items-center">
              <div className="bg-blue-100 rounded-full p-2 mr-4">
                <FileText className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Total Templates</p>
                <div className="flex items-center">
                  <h3 className="text-2xl font-bold mr-2">{stats.templates.count}</h3>
                  <span className={`text-xs px-1 py-0.5 rounded-sm ${stats.templates.change >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {stats.templates.change >= 0 ? '+' : ''}{stats.templates.change}%
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">{stats.templates.period}</p>
              </div>
            </div>
          </ResolvedCardContent>
        </ResolvedCard>

        {/* Total Views */}
        <ResolvedCard>
          <ResolvedCardContent className="p-6">
            <div className="flex items-center">
              <div className="bg-green-100 rounded-full p-2 mr-4">
                <Eye className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Total Views</p>
                <div className="flex items-center">
                  <h3 className="text-2xl font-bold mr-2">{stats.views.count}</h3>
                  <span className={`text-xs px-1 py-0.5 rounded-sm ${stats.views.change >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {stats.views.change >= 0 ? '+' : ''}{stats.views.change}%
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">{stats.views.period}</p>
              </div>
            </div>
          </ResolvedCardContent>
        </ResolvedCard>

        {/* Engagement */}
        <ResolvedCard>
          <ResolvedCardContent className="p-6">
            <div className="flex items-center">
              <div className="bg-purple-100 rounded-full p-2 mr-4">
                <BarChart2 className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Engagement</p>
                <div className="flex items-center">
                  <h3 className="text-2xl font-bold mr-2">{stats.engagement.count}</h3>
                  <span className={`text-xs px-1 py-0.5 rounded-sm ${stats.engagement.change >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {stats.engagement.change >= 0 ? '+' : ''}{stats.engagement.change}%
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">{stats.engagement.period}</p>
              </div>
            </div>
          </ResolvedCardContent>
        </ResolvedCard>

        {/* Followers */}
        <ResolvedCard>
          <ResolvedCardContent className="p-6">
            <div className="flex items-center">
              <div className="bg-yellow-100 rounded-full p-2 mr-4">
                <Users className="h-5 w-5 text-yellow-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Followers</p>
                <div className="flex items-center">
                  <h3 className="text-2xl font-bold mr-2">{stats.followers.count}</h3>
                  <span className={`text-xs px-1 py-0.5 rounded-sm ${stats.followers.change >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {stats.followers.change >= 0 ? '+' : ''}{stats.followers.change}%
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">{stats.followers.period}</p>
              </div>
            </div>
          </ResolvedCardContent>
        </ResolvedCard>
      </div>

      {/* Tabs Navigation */}
      <ResolvedTabs defaultValue="overview" className="mb-8">
        <ResolvedTabsList>
          <ResolvedTabsTrigger value="overview" onClick={() => setActiveTab('overview')}>Overview</ResolvedTabsTrigger>
          <ResolvedTabsTrigger value="templates" onClick={() => setActiveTab('templates')}>Templates</ResolvedTabsTrigger>
          <ResolvedTabsTrigger value="analytics" onClick={() => setActiveTab('analytics')}>Analytics</ResolvedTabsTrigger>
        </ResolvedTabsList>

        <ResolvedTabsContent value="overview" className="mt-6">
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">Recent Templates</h2>
              <Link href="/dashboard-view/templates" className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                View All →
              </Link>
            </div>

            <div className="space-y-4">
              {recentTemplates.map(template => (
                <ResolvedCard key={template.id}>
                  <ResolvedCardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-4">
                        <div className="h-12 w-12 bg-gray-200 rounded"></div>
                        <div>
                          <h3 className="font-medium">{template.title}</h3>
                          <div className="flex space-x-4 text-xs text-gray-500 mt-1">
                            <span>{template.views} views</span>
                            <span>{template.likes} likes</span>
                            <span>{template.shares} shares</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-gray-500">{template.date}</div>
                      </div>
                    </div>
                  </ResolvedCardContent>
                </ResolvedCard>
              ))}
            </div>
          </div>
        </ResolvedTabsContent>

        <ResolvedTabsContent value="templates" className="mt-6">
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-8 text-center">
            <h3 className="text-lg font-medium text-gray-700 mb-2">Template Management</h3>
            <p className="text-gray-500 mb-4">
              View and manage all your templates in one place.
            </p>
            <Link href="/dashboard-view/templates">
              <ResolvedButton>
                Go to Templates
              </ResolvedButton>
            </Link>
          </div>
        </ResolvedTabsContent>

        <ResolvedTabsContent value="analytics" className="mt-6">
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-8 text-center">
            <h3 className="text-lg font-medium text-gray-700 mb-2">Performance Analytics</h3>
            <p className="text-gray-500 mb-4">
              View detailed analytics about your template performance.
            </p>
            <Link href="/dashboard-view/analytics">
              <ResolvedButton>
                View Analytics
              </ResolvedButton>
            </Link>
          </div>
        </ResolvedTabsContent>
      </ResolvedTabs>

      {/* Business Features Section */}
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Business Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <ResolvedCard className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-100">
            <ResolvedCardContent className="p-6">
              <h3 className="font-semibold text-blue-800 mb-2">Trend Prediction</h3>
              <p className="text-sm text-blue-600 mb-4">
                Discover emerging content trends before they peak.
              </p>
              <Link href="/dashboard-view/trend-predictions-dashboard">
                <ResolvedButton 
                  variant="outline"
                  className="w-full border-blue-200 text-blue-700 hover:bg-blue-100"
                >
                  View Predictions
                </ResolvedButton>
              </Link>
            </ResolvedCardContent>
          </ResolvedCard>

          <ResolvedCard className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-100">
            <ResolvedCardContent className="p-6">
              <h3 className="font-semibold text-purple-800 mb-2">Template Remix</h3>
              <p className="text-sm text-purple-600 mb-4">
                Create new templates based on top performers.
              </p>
              <Link href="/dashboard-view/remix">
                <ResolvedButton 
                  variant="outline" 
                  className="w-full border-purple-200 text-purple-700 hover:bg-purple-100"
                >
                  Remix Templates
                </ResolvedButton>
              </Link>
            </ResolvedCardContent>
          </ResolvedCard>

          <ResolvedCard className="bg-gradient-to-br from-green-50 to-teal-50 border-green-100">
            <ResolvedCardContent className="p-6">
              <h3 className="font-semibold text-green-800 mb-2">Video Analyzer</h3>
              <p className="text-sm text-green-600 mb-4">
                Analyze video content for optimization opportunities.
              </p>
              <Link href="/dashboard-view/video-analyzer">
                <ResolvedButton 
                  variant="outline" 
                  className="w-full border-green-200 text-green-700 hover:bg-green-100"
                >
                  Analyze Videos
                </ResolvedButton>
              </Link>
            </ResolvedCardContent>
          </ResolvedCard>
        </div>
      </div>
    </div>
  );
} 