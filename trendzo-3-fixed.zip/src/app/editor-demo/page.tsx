"use client"

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function EditorDemoPage() {
  const router = useRouter()
  
  useEffect(() => {
    // Redirect to the editor page
    router.push('/editor')
  }, [router])
  
  return (
    <div className="flex items-center justify-center h-screen bg-gray-50">
      <div className="text-center">
        <h1 className="text-2xl font-semibold text-gray-800 mb-4">Redirecting to Editor Demo</h1>
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">
          If you are not redirected automatically,{' '}
          <a href="/editor" className="text-blue-600 hover:underline">click here</a>.
        </p>
      </div>
    </div>
  )
} 