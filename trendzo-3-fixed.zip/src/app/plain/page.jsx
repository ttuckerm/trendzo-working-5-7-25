export default function PlainPage() {
  return (
    <div>
      <style jsx>{`
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 20px;
          background-color: #f5f5f5;
        }
        .container {
          max-width: 1000px;
          margin: 0 auto;
          background-color: white;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
          color: #3b82f6;
          margin-top: 0;
        }
        .stat-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
          gap: 16px;
          margin-bottom: 20px;
        }
        .stat-card {
          background-color: white;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          padding: 16px;
        }
        .stat-label {
          color: #6b7280;
          font-size: 14px;
          margin-bottom: 8px;
        }
        .stat-value {
          font-size: 24px;
          font-weight: bold;
        }
        .template-list {
          list-style-type: none;
          padding: 0;
        }
        .template-list li {
          padding: 12px 16px;
          border-bottom: 1px solid #e5e7eb;
        }
      `}</style>
      
      <div className="container">
        <h1>Trendzo Dashboard</h1>
        <p>This is a simplified version of the dashboard</p>
        
        <h2>Statistics</h2>
        <div className="stat-grid">
          <div className="stat-card">
            <div className="stat-label">Templates Created</div>
            <div className="stat-value">12</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Total Views</div>
            <div className="stat-value">8.5K</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Active Trends</div>
            <div className="stat-value">24</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Performance Score</div>
            <div className="stat-value">85%</div>
          </div>
        </div>
        
        <h2>Recent Templates</h2>
        <ul className="template-list">
          <li>Product Showcase</li>
          <li>Dance Challenge</li>
          <li>Tutorial Format</li>
          <li>Trend Reaction</li>
          <li>Story Time Format</li>
        </ul>
      </div>
    </div>
  )
} 