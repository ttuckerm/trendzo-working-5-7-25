'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import { 
  ChevronLeft, 
  Calendar, 
  TrendingUp, 
  UserCheck, 
  Users, 
  ThumbsUp, 
  Eye, 
  Share2,
  Download,
  Star,
  Clock,
  Tag,
  Edit
} from 'lucide-react';
import { 
  Button, 
  Card, 
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
  Badge
} from '@/components/ui/ui-compatibility';
import { TrendingTemplate } from '@/lib/types/trendingTemplate';
import { useToast } from '@/components/ui/use-toast';
import { formatDistanceToNow } from 'date-fns';
import { resolveComponents, initializeComponentResolution } from '@/lib/utils/import-resolver';
import { useComponentFix, forceReinitializeComponents } from '@/lib/utils/component-fix';
import VelocityScoreIndicator from '@/components/ui/VelocityScoreIndicator';

// Initialize component resolution system
if (typeof window !== 'undefined') {
  initializeComponentResolution();
}

// Resolve UI components to ensure they work correctly
const UIComponents = resolveComponents({
  Button, 
  Card, 
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
  Badge
});

export default function TemplateViewPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [template, setTemplate] = useState<TrendingTemplate | null>(null);
  
  // Get the template ID from the URL params
  const templateId = params.id;
  
  // Destructure UI components
  const {
    Button, 
    Card, 
    CardContent,
    CardDescription,
    CardFooter,
    CardHeader,
    CardTitle,
    Badge
  } = UIComponents;
  
  // Initialize component resolution on mount
  useEffect(() => {
    // Add component fix to handle removeChild errors
    const componentFixCleanup = useComponentFix();
    
    // Force reinitialize components to fix any existing issues
    forceReinitializeComponents();
    
    // Clean up when component unmounts
    return () => {
      if (typeof componentFixCleanup === 'function') {
        componentFixCleanup();
      }
    };
  }, []);
  
  useEffect(() => {
    // Fetch template data
    fetchTemplateData();
  }, [templateId]);
  
  const fetchTemplateData = async () => {
    try {
      setLoading(true);
      
      // In development, use mock data
      if (process.env.NODE_ENV === 'development') {
        // Simulate API call with delay
        await new Promise(resolve => setTimeout(resolve, 1200));
        
        // Use a mock template
        const mockTemplate: TrendingTemplate = {
          id: templateId as string,
          title: 'Product Showcase Template',
          description: 'A sleek product showcase template with smooth transitions and dynamic text elements. Perfect for highlighting product features and benefits.',
          thumbnailUrl: 'https://placehold.co/800x600/7950f2/ffffff?text=Product+Template',
          videoUrl: 'https://example.com/videos/product-template.mp4',
          category: 'Product',
          tags: ['ecommerce', 'showcase', 'product reveal', 'features'],
          authorName: 'Creative Studios',
          authorId: 'creator-123',
          authorVerified: true,
          authorAvatar: 'https://placehold.co/100x100/7950f2/ffffff?text=CS',
          stats: {
            views: 12589,
            likes: 2345,
            usageCount: 876,
            commentCount: 345,
            shareCount: 156
          },
          createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          isPremium: false,
          isVerified: true,
          ranking: 4,
          trendingScore: 87,
          trendData: {
            dailyViews: {
              '2023-01-01': 120,
              '2023-01-02': 156,
              '2023-01-03': 189,
              '2023-01-04': 220,
              '2023-01-05': 267
            },
            growthRate: 0.15,
            velocityScore: 0.78,
            dailyGrowth: 0.12,
            weeklyGrowth: 0.35,
            confidenceScore: 0.87,
            daysUntilPeak: 14,
            growthTrajectory: 'exponential'
          },
          expertInsights: {
            tags: [
              {
                id: 'tag-1',
                tag: 'High Conversion Potential',
                category: 'engagement',
                addedBy: 'expert-1',
                addedAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
                confidence: 0.9
              },
              {
                id: 'tag-2',
                tag: 'Strong Visual Impact',
                category: 'content',
                addedBy: 'expert-2',
                addedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
                confidence: 0.85
              }
            ],
            notes: 'This template performs exceptionally well for physical products with strong visual appeal. The transitions are smooth and maintain viewer attention.',
            recommendedUses: ['Product launches', 'Feature highlights', 'E-commerce listings'],
            performanceRating: 4.7,
            audienceRecommendation: ['Shoppers', 'Product researchers', 'Brand followers']
          }
        };
        
        setTemplate(mockTemplate);
        setLoading(false);
        return;
      }
      
      // For production, fetch from API
      const response = await fetch(`/api/templates/${templateId}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch template data');
      }
      
      const data = await response.json();
      setTemplate(data);
      
    } catch (error) {
      console.error('Error fetching template:', error);
      toast({
        title: 'Error',
        description: 'Failed to load the template. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };
  
  // Format numbers for display
  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };
  
  // Handle use template button click
  const handleUseTemplate = () => {
    router.push(`/dashboard-view/remix/${templateId}`);
  };
  
  // Loading state
  if (loading) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div className="flex items-center mb-6">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => router.back()}
            className="mr-2"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back
          </Button>
          <div className="h-8 w-48 bg-gray-200 animate-pulse rounded"></div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="col-span-1 lg:col-span-2">
            <div className="aspect-video w-full bg-gray-200 animate-pulse rounded-lg"></div>
            
            <div className="mt-6 space-y-4">
              <div className="h-8 w-3/4 bg-gray-200 animate-pulse rounded"></div>
              <div className="h-4 w-full bg-gray-200 animate-pulse rounded"></div>
              <div className="h-4 w-full bg-gray-200 animate-pulse rounded"></div>
              <div className="h-4 w-2/3 bg-gray-200 animate-pulse rounded"></div>
            </div>
          </div>
          
          <div className="col-span-1">
            <div className="h-96 bg-gray-200 animate-pulse rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }
  
  // Error state
  if (!template) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div className="flex items-center mb-6">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => router.back()}
            className="mr-2"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back
          </Button>
          <h1 className="text-2xl font-bold">Template Not Found</h1>
        </div>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-12">
              <div className="bg-red-100 text-red-800 rounded-full p-3 w-fit mx-auto mb-4">
                <Eye className="h-6 w-6" />
              </div>
              <h2 className="text-xl font-semibold mb-2">Template Not Found</h2>
              <p className="text-gray-500 mb-6">
                We couldn't find the template you're looking for. It may have been removed or is no longer available.
              </p>
              <Button onClick={() => router.push('/trend-predictions')}>
                Browse Trend Predictions
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // Template created date
  const createdDate = formatDistanceToNow(new Date(template.createdAt), { addSuffix: true });
  
  // Growth trajectory display
  const getTrajectoryClass = (trajectory?: string) => {
    switch (trajectory) {
      case 'exponential':
        return 'bg-green-100 text-green-800';
      case 'linear':
        return 'bg-blue-100 text-blue-800';
      case 'plateauing':
        return 'bg-amber-100 text-amber-800';
      case 'volatile':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => router.back()}
            className="mr-2"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back
          </Button>
          <h1 className="text-2xl font-bold">{template.title}</h1>
        </div>
        <div>
          {template.trendData?.confidenceScore && (
            <Badge 
              className={`mr-2 ${
                template.trendData.confidenceScore >= 0.8 ? 'bg-green-100 text-green-800' :
                template.trendData.confidenceScore >= 0.6 ? 'bg-amber-100 text-amber-800' :
                'bg-red-100 text-red-800'
              }`}
            >
              <TrendingUp className="h-3 w-3 mr-1" />
              {Math.round(template.trendData.confidenceScore * 100)}% Confidence
            </Badge>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="col-span-1 lg:col-span-2">
          {/* Template Preview */}
          <div className="aspect-video w-full bg-gray-100 rounded-lg overflow-hidden relative">
            <Image 
              src={template.thumbnailUrl} 
              alt={template.title}
              fill
              style={{ objectFit: 'cover' }}
            />
            {template.isPremium && (
              <div className="absolute top-3 right-3">
                <Badge className="bg-yellow-100 text-yellow-800">
                  <Star className="h-3 w-3 mr-1 fill-yellow-500 stroke-yellow-800" />
                  Premium
                </Badge>
              </div>
            )}
          </div>
          
          {/* Template Description */}
          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-2">Description</h2>
            <p className="text-gray-700">{template.description}</p>
            
            {/* Tags */}
            <div className="mt-4 flex flex-wrap gap-2">
              {template.tags.map(tag => (
                <Badge key={tag} variant="outline">
                  {tag}
                </Badge>
              ))}
            </div>
            
            {/* Author Info */}
            <div className="mt-6 flex items-center">
              <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-200 relative">
                {template.authorAvatar ? (
                  <Image 
                    src={template.authorAvatar} 
                    alt={template.authorName}
                    fill
                    style={{ objectFit: 'cover' }}
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-purple-100 text-purple-800 font-semibold">
                    {template.authorName.charAt(0)}
                  </div>
                )}
              </div>
              <div className="ml-3">
                <div className="flex items-center">
                  <span className="font-medium">{template.authorName}</span>
                  {template.authorVerified && (
                    <UserCheck className="h-4 w-4 text-blue-500 ml-1" />
                  )}
                </div>
                <span className="text-sm text-gray-500">Created {createdDate}</span>
              </div>
            </div>
          </div>
          
          {/* Stats Section */}
          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-4">Stats</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 flex items-center">
                  <Eye className="h-5 w-5 text-gray-500 mr-3" />
                  <div>
                    <p className="text-lg font-semibold">{formatNumber(template.stats.views)}</p>
                    <p className="text-xs text-gray-500">Views</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 flex items-center">
                  <ThumbsUp className="h-5 w-5 text-gray-500 mr-3" />
                  <div>
                    <p className="text-lg font-semibold">{formatNumber(template.stats.likes)}</p>
                    <p className="text-xs text-gray-500">Likes</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 flex items-center">
                  <Share2 className="h-5 w-5 text-gray-500 mr-3" />
                  <div>
                    <p className="text-lg font-semibold">{formatNumber(template.stats.shareCount || 0)}</p>
                    <p className="text-xs text-gray-500">Shares</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 flex items-center">
                  <Download className="h-5 w-5 text-gray-500 mr-3" />
                  <div>
                    <p className="text-lg font-semibold">{formatNumber(template.stats.usageCount)}</p>
                    <p className="text-xs text-gray-500">Uses</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
        
        <div className="col-span-1">
          {/* Trend Analysis Card */}
          <Card className="mb-6 sticky top-6">
            <CardHeader>
              <CardTitle>Trend Analysis</CardTitle>
              <CardDescription>AI-powered trend predictions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Confidence Score */}
              {template.trendData?.confidenceScore && (
                <div>
                  <p className="text-sm font-medium mb-1">Confidence Score</p>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className={`h-2.5 rounded-full ${
                        template.trendData.confidenceScore >= 0.8 ? 'bg-green-600' :
                        template.trendData.confidenceScore >= 0.6 ? 'bg-amber-500' :
                        'bg-red-500'
                      }`}
                      style={{ width: `${template.trendData.confidenceScore * 100}%` }}
                    ></div>
                  </div>
                  <p className="text-right text-xs text-gray-500 mt-1">
                    {Math.round(template.trendData.confidenceScore * 100)}%
                  </p>
                </div>
              )}
              
              {/* Velocity Score */}
              {template.trendData?.velocityScore !== undefined && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <TrendingUp className="h-4 w-4 text-gray-500 mr-2" />
                    <span className="text-sm">Velocity Score</span>
                  </div>
                  <VelocityScoreIndicator 
                    velocityScore={template.trendData.velocityScore * 10}
                    showLabel={false}
                    size="md"
                  />
                </div>
              )}
              
              {/* Days Until Peak */}
              {template.trendData?.daysUntilPeak && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 text-gray-500 mr-2" />
                    <span className="text-sm">Days Until Peak</span>
                  </div>
                  <Badge variant="outline">
                    {template.trendData.daysUntilPeak} days
                  </Badge>
                </div>
              )}
              
              {/* Growth Trajectory */}
              {template.trendData?.growthTrajectory && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <TrendingUp className="h-4 w-4 text-gray-500 mr-2" />
                    <span className="text-sm">Growth Trajectory</span>
                  </div>
                  <Badge className={getTrajectoryClass(template.trendData.growthTrajectory)}>
                    {template.trendData.growthTrajectory}
                  </Badge>
                </div>
              )}
              
              {/* Target Audience */}
              {template.expertInsights?.audienceRecommendation && (
                <div>
                  <div className="flex items-center mb-2">
                    <Users className="h-4 w-4 text-gray-500 mr-2" />
                    <span className="text-sm">Target Audience</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {template.expertInsights.audienceRecommendation.map(audience => (
                      <Badge key={audience} variant="outline" className="text-xs">
                        {audience}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Expert Insights */}
              {template.expertInsights?.tags && template.expertInsights.tags.length > 0 && (
                <div>
                  <div className="flex items-center mb-2">
                    <Tag className="h-4 w-4 text-gray-500 mr-2" />
                    <span className="text-sm">Expert Insights</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {template.expertInsights.tags.map(tag => (
                      <Badge 
                        key={tag.id} 
                        className="bg-purple-100 text-purple-800"
                      >
                        {tag.tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Expert Notes */}
              {template.expertInsights?.notes && (
                <div className="bg-gray-50 p-3 rounded-md">
                  <p className="text-xs text-gray-700">
                    "{template.expertInsights.notes}"
                  </p>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <Button 
                className="w-full" 
                onClick={handleUseTemplate}
              >
                Use This Template
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full" 
                onClick={() => router.push(`/trend-predictions?templateId=${template.id}`)}
              >
                <TrendingUp className="h-4 w-4 mr-2" />
                View Trend Prediction
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
} 