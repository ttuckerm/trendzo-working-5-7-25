"use client";

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2 } from 'lucide-react';

export default function TemplatesRedirect() {
  const router = useRouter();
  
  useEffect(() => {
    // Redirect to the templates-browse page
    router.push('/templates-browse');
  }, [router]);
  
  // Show a loading spinner while redirecting
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-8">
      <Loader2 className="h-8 w-8 text-blue-600 animate-spin mb-4" />
      <h1 className="text-xl font-semibold mb-2">Redirecting...</h1>
      <p className="text-gray-600">Please wait while we redirect you to the templates browser.</p>
    </div>
  );
} 