'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2 } from 'lucide-react';

/**
 * This page handles redirecting users from /dashboard to the dashboard in the route group
 * Since there's a landing page at the root URL, we need to handle this specially
 */
export default function DashboardRedirect() {
  const router = useRouter();
  
  useEffect(() => {
    // Redirect to the dashboard inside the dashboard route group
    // Since we're using client-side redirect, this should bypass any middleware issues
    router.replace('/dashboard-view');
  }, [router]);
  
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto" />
        <p className="mt-4 text-gray-600">Loading dashboard...</p>
      </div>
    </div>
  );
} 