"use client"

import { useState, useEffect } from 'react';
import { useSubscription } from '@/lib/contexts/SubscriptionContext'
import { BarChart2, TrendingUp, Lock, Eye, Filter, Share2, ThumbsUp, BarChart, PieChart } from 'lucide-react'
import Link from 'next/link'
import PerformanceChart from '@/components/analytics/PerformanceChart'
import TemplateComparison from '@/components/analytics/TemplateComparison'
import TemplateMetricsCard from '@/components/analytics/TemplateMetricsCard'

// Fix the Badge component by creating a simple inline version
const Badge = ({ children, color }: { children: React.ReactNode, color?: string }) => {
  const colorClasses = {
    purple: 'bg-purple-100 text-purple-800',
    blue: 'bg-blue-100 text-blue-800',
    gray: 'bg-gray-100 text-gray-800',
  };
  
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${colorClasses[color as keyof typeof colorClasses] || colorClasses.gray}`}>
      {children}
    </span>
  );
};

// Types
interface Template {
  id: string;
  title: string;
  category: string;
  thumbnailUrl: string;
  stats: {
    views: number;
    likes: number;
    comments: number;
    shares: number;
    engagementRate: number;
  };
  analyticsData: {
    growthRate: number;
    viewTrend: string;
    bestPerformingDemographic: string;
    averageCompletionRate: number;
    conversionRate: number;
  };
  historyData: {
    dates: string[];
    views: number[];
    engagementRate: number[];
  };
  industryBenchmarks: {
    views: number;
    engagementRate: number;
  };
}

export default function AnalyticsPage() {
  const { tier, hasPremium } = useSubscription()
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | 'all'>('30d')
  const [category, setCategory] = useState<string>('All')
  const [sort, setSort] = useState<'views' | 'engagement' | 'growth'>('views')
  const [templates, setTemplates] = useState<Template[]>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null)
  const [compareTemplate, setCompareTemplate] = useState<string | null>(null)
  const [comparisonMode, setComparisonMode] = useState<boolean>(false)

  // Fetch analytics data
  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        setLoading(true)
        const response = await fetch(`/api/templates/analytics?timeRange=${timeRange}&category=${category}&sort=${sort}`)
        
        if (!response.ok) {
          throw new Error('Failed to fetch analytics data')
        }
        
        const data = await response.json()
        
        if (data.success && data.templates) {
          setTemplates(data.templates)
          // Set the first template as selected if none is selected
          if (!selectedTemplate && data.templates.length > 0) {
            setSelectedTemplate(data.templates[0].id)
          }
        }
      } catch (error) {
        console.error('Error fetching analytics:', error)
      } finally {
        setLoading(false)
      }
    }
    
    fetchAnalytics()
  }, [timeRange, category, sort])
  
  // TEMPORARILY COMMENTED OUT FOR DEVELOPMENT/TESTING
  // If user doesn't have premium, show upgrade prompt
  /*
  if (!hasPremium) {
    return (
      <div className="flex flex-col items-center justify-center rounded-lg border border-gray-200 bg-white p-12 text-center">
        <div className="mb-4 rounded-full bg-blue-100 p-4">
          <Lock className="h-8 w-8 text-blue-600" />
        </div>
        <h1 className="mb-2 text-2xl font-bold text-gray-900">Premium Feature</h1>
        <p className="mb-6 max-w-md text-gray-600">
          Performance analytics is available for Premium and Business subscribers. Upgrade your plan to access detailed insights about your content performance.
        </p>
        <div className="flex gap-4">
          <Link
            href="/pricing"
            className="rounded-md bg-blue-600 px-6 py-2 font-medium text-white hover:bg-blue-700"
          >
            Upgrade to Premium
          </Link>
          <Link
            href="/dashboard"
            className="rounded-md border border-gray-300 px-6 py-2 font-medium text-gray-700 hover:bg-gray-50"
          >
            Back to Dashboard
          </Link>
        </div>
      </div>
    )
  }
  */
  
  // Get the selected template data
  const selectedTemplateData = templates.find(t => t.id === selectedTemplate)
  const compareTemplateData = templates.find(t => t.id === compareTemplate)
  
  // Prepare chart data
  const prepareViewChartData = () => {
    if (!selectedTemplateData) return []
    
    return selectedTemplateData.historyData.dates.map((date, index) => ({
      date,
      value: selectedTemplateData.historyData.views[index],
      benchmark: selectedTemplateData.industryBenchmarks.views
    }))
  }
  
  const prepareEngagementChartData = () => {
    if (!selectedTemplateData) return []
    
    return selectedTemplateData.historyData.dates.map((date, index) => ({
      date,
      value: selectedTemplateData.historyData.engagementRate[index] * 100, // Convert to percentage
      benchmark: selectedTemplateData.industryBenchmarks.engagementRate * 100 // Convert to percentage
    }))
  }
  
  // Prepare comparison data
  const prepareComparisonData = () => {
    if (!selectedTemplateData) return []
    
    const metrics = [
      { 
        name: 'Engagement', 
        template1: Math.round(selectedTemplateData.stats.engagementRate * 100),
        template2: compareTemplateData ? Math.round(compareTemplateData.stats.engagementRate * 100) : undefined,
        fullMark: 100 
      },
      { 
        name: 'Growth', 
        template1: Math.round(selectedTemplateData.analyticsData.growthRate * 100),
        template2: compareTemplateData ? Math.round(compareTemplateData.analyticsData.growthRate * 100) : undefined,
        fullMark: 100 
      },
      { 
        name: 'Completion', 
        template1: Math.round(selectedTemplateData.analyticsData.averageCompletionRate * 100),
        template2: compareTemplateData ? Math.round(compareTemplateData.analyticsData.averageCompletionRate * 100) : undefined,
        fullMark: 100 
      },
      { 
        name: 'Conversion', 
        template1: Math.round(selectedTemplateData.analyticsData.conversionRate * 100),
        template2: compareTemplateData ? Math.round(compareTemplateData.analyticsData.conversionRate * 100) : undefined,
        fullMark: 100 
      },
      { 
        name: 'Shares', 
        template1: Math.min(100, Math.round((selectedTemplateData.stats.shares / selectedTemplateData.stats.views) * 1000)),
        template2: compareTemplateData ? Math.min(100, Math.round((compareTemplateData.stats.shares / compareTemplateData.stats.views) * 1000)) : undefined,
        fullMark: 100 
      }
    ]
    
    return metrics
  }

  // Calculate metrics for the metrics card
  const calculateMetrics = () => {
    if (!selectedTemplateData) return []
    
    const engagementVsAvg = Math.round(
      ((selectedTemplateData.stats.engagementRate / selectedTemplateData.industryBenchmarks.engagementRate) - 1) * 100
    )
    
    const viewsVsAvg = Math.round(
      ((selectedTemplateData.stats.views / selectedTemplateData.industryBenchmarks.views) - 1) * 100
    )
    
    return [
      {
        label: 'Total Views',
        value: selectedTemplateData.stats.views,
        change: viewsVsAvg,
        icon: <Eye size={16} className="text-blue-500" />,
        color: 'bg-blue-100'
      },
      {
        label: 'Engagement Rate',
        value: `${(selectedTemplateData.stats.engagementRate * 100).toFixed(1)}%`,
        change: engagementVsAvg,
        icon: <TrendingUp size={16} className="text-green-500" />,
        color: 'bg-green-100'
      },
      {
        label: 'Likes',
        value: selectedTemplateData.stats.likes,
        icon: <ThumbsUp size={16} className="text-pink-500" />,
        color: 'bg-pink-100'
      },
      {
        label: 'Shares',
        value: selectedTemplateData.stats.shares,
        icon: <Share2 size={16} className="text-purple-500" />,
        color: 'bg-purple-100'
      }
    ]
  }
  
  // Format view numbers
  const formatViews = (value: number) => {
    if (value >= 1000000) {
      return (value / 1000000).toFixed(1) + 'M'
    } else if (value >= 1000) {
      return (value / 1000).toFixed(1) + 'K'
    }
    return value.toString()
  }
  
  // Format percentage values
  const formatPercent = (value: number) => {
    return value.toFixed(1) + '%'
  }
  
  // Loading state
  if (loading) {
    return <div className="flex h-64 items-center justify-center">Loading analytics data...</div>
  }
  
  // Premium users see the analytics content
  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Performance Analytics</h1>
          <p className="text-gray-600">Track and optimize your content performance</p>
        </div>
        
        {/* Filter Controls */}
        <div className="flex flex-wrap gap-2">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value as any)}
            className="rounded-md border border-gray-300 px-3 py-1.5 text-sm"
          >
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 90 days</option>
            <option value="all">All time</option>
          </select>
          
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="rounded-md border border-gray-300 px-3 py-1.5 text-sm"
          >
            <option value="All">All Categories</option>
            <option value="Tutorial">Tutorial</option>
            <option value="Marketing">Marketing</option>
            <option value="Dance">Dance</option>
            <option value="Lifestyle">Lifestyle</option>
            <option value="Comedy">Comedy</option>
            <option value="Fashion">Fashion</option>
          </select>
          
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as any)}
            className="rounded-md border border-gray-300 px-3 py-1.5 text-sm"
          >
            <option value="views">Sort by Views</option>
            <option value="engagement">Sort by Engagement</option>
            <option value="growth">Sort by Growth</option>
          </select>
        </div>
      </div>
      
      {/* Template Selection */}
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-semibold">
            {comparisonMode ? (
              <span className="flex items-center text-purple-600">
                <span className="mr-2">Select template to compare</span>
                <Badge color="purple">Comparison mode</Badge>
              </span>
            ) : (
              <span>Select Template to Analyze</span>
            )}
          </h2>
          {compareTemplate && (
            <button
              onClick={() => {
                setCompareTemplate(null)
                setComparisonMode(false)
              }}
              className="text-sm text-red-600 hover:text-red-800"
            >
              Clear Comparison
            </button>
          )}
          {comparisonMode && (
            <button
              onClick={() => setComparisonMode(false)}
              className="text-sm text-gray-600 hover:text-gray-800"
            >
              Cancel
            </button>
          )}
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {templates.map((template) => (
            <div
              key={template.id}
              onClick={() => {
                if (selectedTemplate === template.id) {
                  // Already selected, do nothing
                } else if (comparisonMode) {
                  // If in comparison mode, set as compare template
                  setCompareTemplate(template.id)
                  setComparisonMode(false)
                } else if (compareTemplate) {
                  // If already comparing, update comparison template
                  setCompareTemplate(template.id)
                } else {
                  // Otherwise, set as primary template
                  setSelectedTemplate(template.id)
                }
              }}
              className={`cursor-pointer overflow-hidden rounded-lg border p-2 transition-all hover:border-blue-400 hover:shadow-md
                ${selectedTemplate === template.id ? 'border-blue-500 bg-blue-50/30 ring-1 ring-blue-500' : 
                  compareTemplate === template.id ? 'border-purple-500 bg-purple-50/30 ring-1 ring-purple-500' : 
                  comparisonMode ? 'border-purple-200 bg-purple-50/10 hover:border-purple-400' :
                  'border-gray-200 bg-white'}`}
            >
              <div className="flex items-center gap-3">
                <div 
                  className="h-12 w-12 flex-shrink-0 overflow-hidden rounded-md bg-gray-100"
                  style={{ backgroundImage: `url(${template.thumbnailUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }}
                />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm text-gray-900 truncate">{template.title}</p>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <span>{formatViews(template.stats.views)} views</span>
                    <span>•</span>
                    <span>{(template.stats.engagementRate * 100).toFixed(1)}% eng.</span>
                  </div>
                </div>
              </div>
              {selectedTemplate === template.id && (
                <div className="mt-2 text-xs text-blue-600">
                  Primary template
                </div>
              )}
              {compareTemplate === template.id && (
                <div className="mt-2 text-xs text-purple-600">
                  Comparison template
                </div>
              )}
              {selectedTemplate !== template.id && compareTemplate !== template.id && (
                <div className="mt-2 text-xs text-gray-500">
                  {comparisonMode ? "Click to compare" : "Click to select"}
                </div>
              )}
            </div>
          ))}
        </div>
        
        {selectedTemplate && !compareTemplate && !comparisonMode && (
          <div className="mt-3 text-center">
            <button
              onClick={() => setComparisonMode(true)}
              className="text-sm text-blue-600 hover:text-blue-800"
            >
              Select another template to compare
            </button>
          </div>
        )}
      </div>
      
      {/* Analytics Dashboard */}
      {selectedTemplateData && (
        <div className="space-y-6">
          {/* Metrics Overview */}
          <TemplateMetricsCard 
            title="Performance Overview" 
            metrics={calculateMetrics()} 
          />
          
          {/* Template Comparison - Move this before the charts when we have a comparison */}
          {selectedTemplate && compareTemplate && (
            <TemplateComparison
              template1={{
                id: selectedTemplateData?.id || '',
                title: selectedTemplateData?.title || '',
                color: '#3b82f6', // blue
                stats: {
                  views: selectedTemplateData?.stats.views || 0,
                  engagementRate: selectedTemplateData?.stats.engagementRate || 0,
                  growthRate: selectedTemplateData?.analyticsData.growthRate || 0,
                  completionRate: selectedTemplateData?.analyticsData.averageCompletionRate || 0
                }
              }}
              template2={compareTemplateData ? {
                id: compareTemplateData.id,
                title: compareTemplateData.title,
                color: '#8b5cf6', // purple
                stats: {
                  views: compareTemplateData.stats.views,
                  engagementRate: compareTemplateData.stats.engagementRate,
                  growthRate: compareTemplateData.analyticsData.growthRate,
                  completionRate: compareTemplateData.analyticsData.averageCompletionRate
                }
              } : undefined}
              metrics={prepareComparisonData()}
              className="mb-6"
              isActive={true}
            />
          )}
          
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            {/* Views Chart */}
            <PerformanceChart
              data={prepareViewChartData()}
              title="View Trends"
              valueLabel="Views"
              formatValue={formatViews}
              color="#3b82f6" // blue
            />
            
            {/* Engagement Chart */}
            <PerformanceChart
              data={prepareEngagementChartData()}
              title="Engagement Rate"
              valueLabel="Engagement %"
              formatValue={formatPercent}
              color="#10b981" // green
            />
          </div>
          
          {/* Additional Details */}
          <div className="rounded-lg border border-gray-200 bg-white p-6">
            <h2 className="mb-4 text-lg font-semibold text-gray-900">Additional Insights</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="rounded-lg border border-gray-100 bg-gray-50 p-4">
                  <h3 className="mb-2 font-medium text-gray-700">Demographic Data</h3>
                  <p className="text-gray-600">
                    Best performing demographic: <span className="font-semibold">{selectedTemplateData.analyticsData.bestPerformingDemographic}</span>
                  </p>
                </div>
                
                <div className="rounded-lg border border-gray-100 bg-gray-50 p-4">
                  <h3 className="mb-2 font-medium text-gray-700">Content Completion</h3>
                  <p className="text-gray-600">
                    Average completion rate: <span className="font-semibold">{(selectedTemplateData.analyticsData.averageCompletionRate * 100).toFixed(1)}%</span>
                  </p>
                </div>
              </div>
              
              <div className="rounded-lg border border-gray-100 bg-gray-50 p-4">
                <h3 className="mb-2 font-medium text-gray-700">Growth Trajectory</h3>
                <p className="text-gray-600">
                  This template is currently <span className="font-semibold">{selectedTemplateData.analyticsData.viewTrend}</span> in popularity.
                  It has a growth rate of <span className="font-semibold">{(selectedTemplateData.analyticsData.growthRate * 100).toFixed(1)}%</span> which is 
                  {selectedTemplateData.analyticsData.growthRate > 0.2 ? ' above average' : ' average'} for its category.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
} 