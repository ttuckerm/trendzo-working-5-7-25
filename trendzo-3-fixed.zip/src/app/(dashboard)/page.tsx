/**
 * CRITICAL FILE: Dashboard Root
 * 
 * PURPOSE: Entry point for the dashboard system
 * 
 * WARNING:
 * - This file is the main entry point for the dashboard
 * - Do NOT redirect to other routes unless specifically required
 * - Must maintain compatibility with dashboard components
 */

"use client"

import { useState } from 'react';
import { 
  BarChart2, 
  TrendingUp, 
  Eye, 
  UserCheck,
  Calendar,
  Layout,
  Star,
  ChevronRight,
  ThumbsUp,
  Share
} from 'lucide-react';
import Link from 'next/link';
import { useSubscription } from '@/lib/contexts/SubscriptionContext';
import StatCard from '@/components/dashboard/StatCard';
import { Card } from '@/components/ui/card-component';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

// Mock data for recent templates
const recentTemplates = [
  {
    id: 'template-1',
    title: 'Product Showcase',
    views: 542,
    likes: 124,
    shares: 47,
    lastEdited: '2023-06-12',
    thumbnail: '/thumbnails/product-1.jpg'
  },
  {
    id: 'template-2',
    title: 'Tutorial Format',
    views: 328,
    likes: 87,
    shares: 32,
    lastEdited: '2023-06-10',
    thumbnail: '/thumbnails/tutorial-1.jpg'
  },
  {
    id: 'template-3',
    title: 'Story Time Format',
    views: 215,
    likes: 63,
    shares: 28,
    lastEdited: '2023-06-08',
    thumbnail: '/thumbnails/story-1.jpg'
  }
];

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState('overview');
  const { tier, hasPremium } = useSubscription();

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-gray-500">Welcome to your Trendzo dashboard</p>
        </div>
        <Button>
          <Layout className="w-4 h-4 mr-2" />
          Create Template
        </Button>
      </div>
      
      {/* Statistics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Templates" 
          value={12} 
          icon={<Layout size={20} />} 
          iconBgColor="bg-blue-100" 
          iconColor="text-blue-600"
          trend={8}
          description="Last 30 days"
        />
        <StatCard 
          title="Total Views" 
          value={8576} 
          icon={<Eye size={20} />} 
          iconBgColor="bg-green-100" 
          iconColor="text-green-600"
          trend={15}
          description="Last 30 days"
        />
        <StatCard 
          title="Engagement" 
          value="4.7%" 
          icon={<TrendingUp size={20} />} 
          iconBgColor="bg-purple-100" 
          iconColor="text-purple-600"
          trend={-2}
          description="Last 30 days"
        />
        <StatCard 
          title="Followers" 
          value={1250} 
          icon={<UserCheck size={20} />} 
          iconBgColor="bg-amber-100" 
          iconColor="text-amber-600"
          trend={5}
          description="Last 30 days"
        />
      </div>
      
      {/* Tabbed Interface */}
      <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold">Recent Templates</h2>
                  <Link href="/template-library" className="text-blue-600 text-sm flex items-center hover:underline">
                    View All <ChevronRight className="ml-1 w-4 h-4" />
                  </Link>
                </div>
                
                <div className="space-y-4">
                  {recentTemplates.map(template => (
                    <div key={template.id} className="border rounded-lg p-4 flex items-center">
                      <div className="w-16 h-16 bg-gray-200 rounded-md flex-shrink-0"></div>
                      <div className="ml-4 flex-grow">
                        <h3 className="font-medium">{template.title}</h3>
                        <div className="flex items-center text-sm text-gray-500 mt-1">
                          <Eye className="w-3 h-3 mr-1" /> {template.views}
                          <ThumbsUp className="w-3 h-3 ml-3 mr-1" /> {template.likes}
                          <Share className="w-3 h-3 ml-3 mr-1" /> {template.shares}
                        </div>
                      </div>
                      <div className="text-sm text-gray-500">
                        <Calendar className="w-3 h-3 inline mr-1" />
                        {template.lastEdited}
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
            
            <div>
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4">Performance</h2>
                <div className="text-center py-12 px-4">
                  <div className="w-24 h-24 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto mb-4">
                    <Star className="w-10 h-10" />
                  </div>
                  <div className="text-3xl font-bold mb-1">85%</div>
                  <p className="text-gray-500 mb-4">Overall Score</p>
                  
                  <Link href="/analytics" className="text-sm text-blue-600 hover:underline">
                    View Performance Analytics
                    {!hasPremium && <Badge className="ml-2 bg-amber-100 text-amber-800">Premium</Badge>}
                  </Link>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="templates">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-6">Template Management</h2>
            <p className="text-gray-500 mb-4">
              Create, edit and manage all your content templates in one place.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="border rounded-lg p-6 text-center">
                <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Layout className="w-8 h-8" />
                </div>
                <h3 className="font-medium mb-2">Create Template</h3>
                <p className="text-sm text-gray-500 mb-4">Start from scratch with a blank template</p>
                <Button size="sm">Get Started</Button>
              </div>
              
              <div className="border rounded-lg p-6 text-center">
                <div className="w-16 h-16 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="w-8 h-8" />
                </div>
                <h3 className="font-medium mb-2">Browse Popular</h3>
                <p className="text-sm text-gray-500 mb-4">See what's trending right now</p>
                <Button size="sm" variant="outline">Browse</Button>
              </div>
              
              <div className="border rounded-lg p-6 text-center">
                <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-8 h-8" />
                </div>
                <h3 className="font-medium mb-2">Performance</h3>
                <p className="text-sm text-gray-500 mb-4">Review your analytics</p>
                <Button size="sm" variant="outline">View Stats</Button>
              </div>
            </div>
          </Card>
        </TabsContent>
        
        <TabsContent value="analytics">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">Content Performance</h2>
              {!hasPremium && (
                <Badge className="bg-amber-100 text-amber-800">
                  Premium Feature
                </Badge>
              )}
            </div>
            
            {hasPremium ? (
              <div className="space-y-6">
                <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                  <p className="text-gray-500">Analytics Chart Placeholder</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-gray-500">Top Performing</p>
                    <p className="font-medium">Product Showcase</p>
                    <div className="flex items-center mt-2 text-sm">
                      <Eye className="w-3 h-3 mr-1" /> 542 views
                    </div>
                  </div>
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-gray-500">Engagement Rate</p>
                    <p className="font-medium">4.7%</p>
                    <div className="flex items-center mt-2 text-sm text-green-600">
                      <TrendingUp className="w-3 h-3 mr-1" /> +0.5%
                    </div>
                  </div>
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-gray-500">Average Views</p>
                    <p className="font-medium">324 per template</p>
                    <div className="flex items-center mt-2 text-sm text-green-600">
                      <TrendingUp className="w-3 h-3 mr-1" /> +12%
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="w-24 h-24 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center mx-auto mb-4">
                  <BarChart2 className="w-10 h-10" />
                </div>
                <h3 className="text-xl font-medium mb-2">Unlock Advanced Analytics</h3>
                <p className="text-gray-500 mb-6 max-w-md mx-auto">
                  Get in-depth insights about your content performance with our premium analytics tools.
                </p>
                <Button>Upgrade to Premium</Button>
              </div>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
