"use client"

import React, { useState } from 'react'
import Link from 'next/link'

// Define test templates
const TEST_TEMPLATES = [
  { id: 'dance-challenge', name: 'Viral Dance Challenge', category: 'Dance' },
  { id: 'product-review', name: 'ASMR Product Review', category: 'Marketing' },
  { id: 'cooking-hack', name: '30-Second Cooking Hack', category: 'Tutorial' },
  { id: 'story-time', name: 'Dramatic Story Time Format', category: 'Comedy' }
]

export default function TestNewsletterPage() {
  const [selectedTemplate, setSelectedTemplate] = useState('dance-challenge')
  const [generatedUrl, setGeneratedUrl] = useState('')
  const [copied, setCopied] = useState(false)
  const [isPremiumMode, setIsPremiumMode] = useState(false)
  const [templateId, setTemplateId] = useState('template-001')
  const [campaign, setCampaign] = useState('test-campaign')
  const [generatedLink, setGeneratedLink] = useState<string | null>(null)
  
  // Generate test link
  const generateLink = () => {
    try {
      // Create a URL that includes the template ID
      const params = new URLSearchParams()
      params.append('template', selectedTemplate)
      params.append('utm_source', 'testing')
      params.append('utm_medium', 'email')
      params.append('utm_campaign', 'testing')
      
      // Add premium mode parameter if selected
      if (isPremiumMode) {
        params.append('to_editor', 'true')
      }
      
      // Build the URL
      const baseUrl = window.location.origin
      // Use the simple-test API route instead of the complex one
      const apiUrl = `/api/newsletter/simple-test?${params.toString()}`
      
      // Set the generated URL
      setGeneratedUrl(`${baseUrl}${apiUrl}`)
    } catch (error) {
      console.error('Error generating link:', error)
    }
  }
  
  // Handle copy to clipboard
  const copyToClipboard = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(generatedUrl)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleGenerate = () => {
    // Get the base URL from window.location
    const baseUrl = window.location.origin;
    
    // Generate the link
    const url = new URL(`${baseUrl}/template-redirect`);
    url.searchParams.append('id', templateId);
    url.searchParams.append('source', 'newsletter');
    
    if (campaign) {
      url.searchParams.append('campaign', campaign);
    }
    
    setGeneratedLink(url.toString());
  };
  
  return (
    <div className="container mx-auto p-8">
      <h1 className="text-2xl font-bold mb-6">Newsletter Link Test Page</h1>
      
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-8">
        <h2 className="text-xl font-semibold mb-4">Generate Test Link</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Template ID</label>
            <input
              type="text"
              value={templateId}
              onChange={(e) => setTemplateId(e.target.value)}
              className="w-full p-2 border rounded"
              placeholder="Enter template ID"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Campaign Name</label>
            <input
              type="text"
              value={campaign}
              onChange={(e) => setCampaign(e.target.value)}
              className="w-full p-2 border rounded"
              placeholder="Enter campaign name"
            />
          </div>
          
          <button
            onClick={handleGenerate}
            className="px-4 py-2 bg-blue-600 text-white rounded-md"
          >
            Generate Link
          </button>
        </div>
        
        {generatedLink && (
          <div className="mt-6 p-4 bg-gray-50 rounded-md">
            <p className="font-medium mb-2">Generated Link:</p>
            <div className="bg-white p-3 border border-gray-300 rounded break-all mb-3">
              {generatedLink}
            </div>
            <div className="flex space-x-4">
              <a
                href={generatedLink}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                Open Link
              </a>
              <button
                onClick={() => navigator.clipboard.writeText(generatedLink)}
                className="text-blue-600 hover:underline"
              >
                Copy Link
              </button>
            </div>
          </div>
        )}
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h2 className="text-xl font-semibold mb-4">Test Templates</h2>
        <p className="mb-4">Click on one of the pre-configured test links below:</p>
        
        <div className="space-y-3">
          <div className="p-3 bg-gray-50 rounded-md">
            <p className="font-medium mb-1">Template 001 (Marketing)</p>
            <Link 
              href="/template-redirect?id=template-001&source=newsletter&campaign=test-campaign"
              className="text-blue-600 hover:underline"
            >
              Test Template 001
            </Link>
          </div>
          
          <div className="p-3 bg-gray-50 rounded-md">
            <p className="font-medium mb-1">Template 002 (Fashion)</p>
            <Link 
              href="/template-redirect?id=template-002&source=newsletter&campaign=test-campaign"
              className="text-blue-600 hover:underline"
            >
              Test Template 002
            </Link>
          </div>
          
          <div className="p-3 bg-gray-50 rounded-md">
            <p className="font-medium mb-1">Template 003 (Food)</p>
            <Link 
              href="/template-redirect?id=template-003&source=newsletter&campaign=test-campaign"
              className="text-blue-600 hover:underline"
            >
              Test Template 003
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
} 