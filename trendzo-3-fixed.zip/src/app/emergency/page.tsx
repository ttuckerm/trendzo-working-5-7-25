"use client"

function EmergencyPage() {
  return (
    <div style={{
      fontFamily: 'Arial, sans-serif',
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '20px',
      backgroundColor: '#f5f5f5'
    }}>
      <div style={{
        backgroundColor: 'white',
        padding: '16px',
        marginBottom: '24px',
        borderRadius: '8px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <div style={{ color: '#3b82f6', fontWeight: 'bold', fontSize: '24px' }}>Trendzo</div>
        <div style={{ 
          backgroundColor: '#dbeafe', 
          color: '#1e40af', 
          padding: '4px 8px',
          borderRadius: '9999px',
          fontSize: '12px',
          fontWeight: 'bold'
        }}>
          EMERGENCY MODE
        </div>
      </div>
      
      <h1 style={{ fontSize: '24px', marginBottom: '8px' }}>Dashboard</h1>
      <p style={{ color: '#4b5563', marginBottom: '24px' }}>Welcome to your Trendzo dashboard</p>
      
      <div style={{ 
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
        gap: '16px',
        marginBottom: '24px'
      }}>
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          padding: '16px'
        }}>
          <div style={{ color: '#6b7280', fontSize: '14px' }}>Templates Created</div>
          <div style={{ fontSize: '24px', fontWeight: 'bold', marginTop: '8px' }}>12</div>
        </div>
        
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          padding: '16px'
        }}>
          <div style={{ color: '#6b7280', fontSize: '14px' }}>Total Views</div>
          <div style={{ fontSize: '24px', fontWeight: 'bold', marginTop: '8px' }}>8.5K</div>
        </div>
        
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          padding: '16px'
        }}>
          <div style={{ color: '#6b7280', fontSize: '14px' }}>Active Trends</div>
          <div style={{ fontSize: '24px', fontWeight: 'bold', marginTop: '8px' }}>24</div>
        </div>
        
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          padding: '16px'
        }}>
          <div style={{ color: '#6b7280', fontSize: '14px' }}>Performance Score</div>
          <div style={{ fontSize: '24px', fontWeight: 'bold', marginTop: '8px' }}>85%</div>
        </div>
      </div>
      
      <div style={{
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        padding: '20px',
        marginBottom: '24px'
      }}>
        <h2 style={{ fontSize: '18px', marginBottom: '16px' }}>Recent Activity</h2>
        <ul style={{ listStyleType: 'none', padding: 0 }}>
          <li style={{ padding: '8px 0', borderBottom: '1px solid #e5e7eb' }}>You created a new template</li>
          <li style={{ padding: '8px 0', borderBottom: '1px solid #e5e7eb' }}>Your account was upgraded to Premium</li>
          <li style={{ padding: '8px 0', borderBottom: '1px solid #e5e7eb' }}>Product showcase reached 1K views</li>
          <li style={{ padding: '8px 0' }}>You connected with a new creator</li>
        </ul>
      </div>
      
      <p style={{ textAlign: 'center', color: '#6b7280', fontSize: '14px', marginTop: '40px' }}>
        This is a static version of the dashboard created for emergency access.
      </p>
    </div>
  );
}

export default EmergencyPage; 