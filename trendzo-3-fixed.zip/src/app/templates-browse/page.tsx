"use client";

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Search } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/unified-card';
import ErrorBoundary from '@/components/ui/error-boundary';
import { TrendingTemplate } from '@/lib/types/trendingTemplate';

/**
 * Templates browsing page
 * Allows users to search and browse through available templates
 */
export default function TemplatesBrowsePage() {
  const [templates, setTemplates] = useState<TrendingTemplate[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Memoized fetch function to avoid recreating on every render
  const fetchTemplates = useCallback(async () => {
    try {
      setLoading(true);
      
      // In development, use mock data
      if (process.env.NODE_ENV === 'development') {
        // Delay to simulate loading
        await new Promise(resolve => setTimeout(resolve, 500));
        setTemplates(getMockTemplates());
        setLoading(false);
        return;
      }
      
      // In production, fetch from API
      const response = await fetch('/api/templates');
      
      if (!response.ok) {
        throw new Error('Failed to fetch templates');
      }
      
      const data = await response.json();
      setTemplates(data.templates);
      setLoading(false);
    } catch (err) {
      console.error('Error fetching templates:', err);
      setError('Failed to load templates');
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTemplates();
  }, [fetchTemplates]);

  // Filter templates based on search query
  const filteredTemplates = templates.filter(template => {
    const query = searchQuery.toLowerCase().trim();
    if (!query) return true;
    
    return (
      template.title.toLowerCase().includes(query) ||
      template.description.toLowerCase().includes(query) ||
      template.category.toLowerCase().includes(query) ||
      template.tags.some(tag => tag.toLowerCase().includes(query))
    );
  });

  return (
    <ErrorBoundary>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Templates</h1>
          
          <div className="relative max-w-md w-full">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              placeholder="Search templates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
          </div>
        ) : error ? (
          <div className="bg-red-50 border-l-4 border-red-400 p-4 my-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        ) : filteredTemplates.length === 0 ? (
          <div className="text-center py-12">
            <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No templates found</h3>
            <p className="mt-1 text-sm text-gray-500">
              {searchQuery ? `No results matching "${searchQuery}"` : "No templates available"}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredTemplates.map((template) => (
              <Link href={`/templates/${template.id}`} key={template.id}>
                <Card className="h-full cursor-pointer hover:shadow-lg transition-shadow">
                  <div className="relative h-48 w-full rounded-t-lg overflow-hidden">
                    <Image
                      src={template.thumbnailUrl || 'https://placehold.co/600x400/e2e8f0/64748b?text=No+Image'}
                      alt={template.title}
                      fill
                      style={{ objectFit: 'cover' }}
                    />
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg text-gray-900 mb-1 line-clamp-1">{template.title}</h3>
                    <p className="text-sm text-gray-600 mb-3 line-clamp-2">{template.description}</p>
                    
                    <div className="flex justify-between items-center text-xs text-gray-500">
                      <div className="flex items-center">
                        {template.authorAvatar ? (
                          <Image
                            src={template.authorAvatar}
                            alt={template.authorName}
                            width={20}
                            height={20}
                            className="rounded-full mr-1"
                          />
                        ) : (
                          <div className="w-5 h-5 bg-gray-200 rounded-full mr-1"></div>
                        )}
                        <span>{template.authorName}</span>
                      </div>
                      
                      <div className="flex space-x-2">
                        <span className="flex items-center">
                          <svg className="h-3 w-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                            <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                          </svg>
                          {formatNumber(template.stats.views)}
                        </span>
                        
                        <span className="flex items-center">
                          <svg className="h-3 w-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z" />
                          </svg>
                          {formatNumber(template.stats.likes)}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
}

// Helper function to format numbers (e.g. 1500 -> 1.5K)
function formatNumber(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  } else {
    return num.toString();
  }
}

// Mock data for development
function getMockTemplates(): TrendingTemplate[] {
  return [
    {
      id: '1',
      title: 'Product Showcase Template',
      description: 'Perfect for showcasing your products with clean transitions and professional effects.',
      thumbnailUrl: 'https://placehold.co/600x400/4f46e5/ffffff?text=Product+Showcase',
      category: 'E-commerce',
      tags: ['product', 'showcase', 'business'],
      authorName: 'Marketing Pro',
      authorAvatar: 'https://randomuser.me/api/portraits/women/44.jpg',
      stats: {
        views: 15420,
        likes: 2300,
        usageCount: 756
      },
      createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: '2',
      title: 'Story Time Animation',
      description: 'Tell your story with beautiful animated transitions that capture attention.',
      thumbnailUrl: 'https://placehold.co/600x400/047857/ffffff?text=Story+Animation',
      category: 'Education',
      tags: ['story', 'animation', 'education'],
      authorName: 'Creative Educator',
      stats: {
        views: 8940,
        likes: 1200,
        usageCount: 432
      },
      createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: '3',
      title: 'Fashion Collection Slideshow',
      description: 'Showcase your fashion collection with this elegant and trendy slideshow template.',
      thumbnailUrl: 'https://placehold.co/600x400/db2777/ffffff?text=Fashion+Slideshow',
      category: 'Fashion',
      tags: ['fashion', 'slideshow', 'collection'],
      authorName: 'Style Maven',
      authorAvatar: 'https://randomuser.me/api/portraits/men/22.jpg',
      stats: {
        views: 21000,
        likes: 3100,
        usageCount: 890
      },
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: '4',
      title: 'Recipe Tutorial Template',
      description: 'Perfect for food creators showcasing recipes with step-by-step instructions.',
      thumbnailUrl: 'https://placehold.co/600x400/ca8a04/ffffff?text=Recipe+Tutorial',
      category: 'Food',
      tags: ['recipe', 'cooking', 'food'],
      authorName: 'Chef Delights',
      stats: {
        views: 12500,
        likes: 2800,
        usageCount: 945
      },
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: '5',
      title: 'Workout Routine Template',
      description: 'Share your fitness routines with this dynamic workout template.',
      thumbnailUrl: 'https://placehold.co/600x400/7e22ce/ffffff?text=Fitness+Template',
      category: 'Fitness',
      tags: ['workout', 'fitness', 'health'],
      authorName: 'Fitness Coach',
      authorAvatar: 'https://randomuser.me/api/portraits/women/67.jpg',
      stats: {
        views: 9800,
        likes: 1700,
        usageCount: 520
      },
      createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: '6',
      title: 'Travel Vlog Template',
      description: 'Share your adventures with this eye-catching travel vlog template.',
      thumbnailUrl: 'https://placehold.co/600x400/0369a1/ffffff?text=Travel+Vlog',
      category: 'Travel',
      tags: ['travel', 'vlog', 'adventure'],
      authorName: 'Wanderlust Explorer',
      stats: {
        views: 18700,
        likes: 3400,
        usageCount: 780
      },
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
    }
  ];
} 