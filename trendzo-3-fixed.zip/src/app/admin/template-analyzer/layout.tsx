export default function TemplateAnalyzerLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
} 