"use client"

import React, { useState, useEffect } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import NewsletterLinkGenerator from './components/NewsletterLinkGenerator'
import NewsletterAnalytics from './components/NewsletterAnalytics'

export default function AdminNewsletterPage() {
  const [appUrl, setAppUrl] = useState<string>('');
  const [debugInfo, setDebugInfo] = useState<any>({
    currentUrl: '',
    baseUrl: '',
    environment: '',
    redirectEnabled: true
  });

  // Get debug info
  useEffect(() => {
    if (typeof window !== 'undefined') {
      setAppUrl(window.location.origin);
      setDebugInfo({
        currentUrl: window.location.href,
        baseUrl: window.location.origin,
        environment: process.env.NODE_ENV || 'unknown',
        redirectEnabled: true,
        userAgent: window.navigator.userAgent,
        timestamp: new Date().toISOString()
      });
    }
  }, []);

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Newsletter Management</h1>
        <p className="text-gray-600">
          Create and manage newsletter integrations for template distribution
        </p>
      </div>

      <Tabs defaultValue="link-generator">
        <TabsList className="mb-6">
          <TabsTrigger value="link-generator">Link Generator</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="templates">Newsletter Templates</TabsTrigger>
          <TabsTrigger value="debug">Debug</TabsTrigger>
        </TabsList>
        
        <TabsContent value="link-generator" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <NewsletterLinkGenerator />
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Link Generator Guide</h2>
              
              <div className="space-y-4 text-sm text-gray-600">
                <div>
                  <h3 className="font-medium text-gray-800 mb-1">1. How to use the link generator</h3>
                  <p>
                    Select a template from the dropdown, add an optional campaign name, 
                    then click "Generate" to create a trackable link for your newsletter.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-800 mb-1">2. Parameters explained</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li><strong>id</strong> - The unique identifier for the template</li>
                    <li><strong>source</strong> - Set to "newsletter" to track all newsletter traffic</li>
                    <li><strong>campaign</strong> - Optional identifier for specific newsletter campaigns</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-800 mb-1">3. Best practices</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Use descriptive campaign names for better analytics</li>
                    <li>Test links before including them in newsletters</li>
                    <li>Always use this tool rather than manually creating links</li>
                    <li>Sort by "Most Popular" to feature trending templates</li>
                    <li>If redirect links don't work, use "Direct Preview Link" option</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="analytics">
          <NewsletterAnalytics />
        </TabsContent>
        
        <TabsContent value="templates">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Newsletter Templates</h2>
            <p className="text-gray-600 mb-8">
              Email templates for newsletter campaigns will be available here.
            </p>
            
            <div className="p-12 border border-dashed border-gray-300 rounded-md flex items-center justify-center">
              <p className="text-gray-500 text-center">
                Newsletter template editor coming soon.<br />
                <span className="text-sm">Create and manage email templates with embedded TikTok template links.</span>
              </p>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="debug">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Link Debugging Information</h2>
            <p className="text-gray-600 mb-4">
              Use this information to troubleshoot newsletter link issues. If users are being redirected to external sites, 
              check that your application's URL configuration is correct.
            </p>
            
            <div className="mb-6">
              <h3 className="font-medium text-gray-800 mb-2">Current Application URL</h3>
              <div className="bg-gray-50 p-3 rounded-md border border-gray-200 font-mono text-sm">
                {appUrl}
              </div>
              <p className="mt-1 text-xs text-gray-500">
                This is used as the base for all generated links
              </p>
            </div>
            
            <div className="mb-6">
              <h3 className="font-medium text-gray-800 mb-2">Test Links</h3>
              <div className="space-y-3">
                <div>
                  <p className="mb-1 text-sm text-gray-700">Direct Template Preview:</p>
                  <div className="bg-gray-50 p-3 rounded-md border border-gray-200 font-mono text-sm break-all">
                    {appUrl}/template-preview?id=example-template-id&source=newsletter&campaign=test-campaign
                  </div>
                </div>
                <div>
                  <p className="mb-1 text-sm text-gray-700">API Redirect:</p>
                  <div className="bg-gray-50 p-3 rounded-md border border-gray-200 font-mono text-sm break-all">
                    {appUrl}/api/template-redirect?id=example-template-id&source=newsletter&campaign=test-campaign
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="font-medium text-gray-800 mb-2">System Information</h3>
              <pre className="bg-gray-50 p-3 rounded-md border border-gray-200 font-mono text-xs overflow-auto">
                {JSON.stringify(debugInfo, null, 2)}
              </pre>
            </div>
            
            <div className="bg-yellow-50 p-4 rounded-md border border-yellow-200">
              <h3 className="font-medium text-yellow-800 mb-2">Troubleshooting Tips</h3>
              <ul className="list-disc pl-5 space-y-1 text-sm text-yellow-700">
                <li>If redirect links don't work, use direct links instead</li>
                <li>Verify your API routes are properly configured</li>
                <li>Check browser console for errors when clicking newsletter links</li>
                <li>Confirm that the template IDs are valid in your database</li>
                <li>If users are redirected to external domains, check for domain configuration issues</li>
              </ul>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 