'use client';

import { ReactNode, useEffect } from 'react';
import { initializeComponentResolution } from '@/lib/utils/import-resolver';

interface CompatibilityProviderProps {
  children: ReactNode;
}

/**
 * CompatibilityProvider
 * 
 * This component initializes the component compatibility layer
 * to ensure all UI components load correctly, especially when
 * there are conflicts between different versions.
 */
export function CompatibilityProvider({ children }: CompatibilityProviderProps) {
  useEffect(() => {
    // Initialize the compatibility layer
    const cleanup = initializeComponentResolution();
    
    // Clean up when the component is unmounted
    return cleanup;
  }, []);
  
  return <>{children}</>;
} 