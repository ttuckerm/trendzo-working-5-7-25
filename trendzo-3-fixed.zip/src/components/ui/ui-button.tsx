"use client";

/**
 * Button Component Wrapper
 * 
 * This is a compatibility layer that ensures Button imports work consistently
 * It re-exports the Button component from the base button.tsx file
 */

import { Button, buttonVariants } from './button';

export { Button, buttonVariants };
export default Button; 