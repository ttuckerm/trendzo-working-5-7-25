"use client";

import Link from 'next/link';
import Image from 'next/image';
import { Clock, TrendingUp, BarChart, ZapIcon, Award } from 'lucide-react';

// Define the template interface with analysis data
export interface TemplateProps {
  id: string;
  category: string;
  duration: string;
  title: string;
  views: string;
  background?: string;
  image?: string;
  // Extended properties for analyzed templates
  templateStructure?: Array<{
    type: string;
    startTime?: number;
    duration?: number;
    purpose?: string;
  }>;
  engagementRate?: number;
  velocityScore?: number;
  aiCategory?: string;
  isAnalyzed?: boolean;
}

// Helper function to generate a slug for routing
export function generateSlug(title: string): string {
  return title.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]+/g, '');
}

export function TemplateCard({ 
  id, 
  category, 
  duration, 
  title, 
  views, 
  background = "bg-gray-100", 
  image,
  templateStructure,
  engagementRate,
  velocityScore,
  aiCategory,
  isAnalyzed = false
}: TemplateProps) {
  // Use the ID directly instead of generating a slug from the title
  
  // Format engagement rate if available
  const formattedEngagement = engagementRate ? 
    `${engagementRate.toFixed(1)}%` : 
    null;
  
  // Determine if this is a trending template based on velocity score
  const isTrending = velocityScore && velocityScore > 7.5;
  
  // Determine badge color based on category
  const getBadgeColor = (category: string) => {
    const colors: Record<string, string> = {
      'Marketing': 'bg-blue-100 text-blue-800',
      'Tutorial': 'bg-green-100 text-green-800',
      'Education': 'bg-green-100 text-green-800',
      'Dance': 'bg-purple-100 text-purple-800',
      'Comedy': 'bg-yellow-100 text-yellow-800',
      'Lifestyle': 'bg-pink-100 text-pink-800'
    };
    
    return colors[category] || 'bg-gray-100 text-gray-800';
  };

  // Determine the correct URL path
  const templateUrl = `/template-library/${id}`;

  return (
    <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow">
      <div className={`relative w-full h-56 ${background} overflow-hidden group`}>
        {/* Category badge */}
        <div className="absolute top-3 left-3 z-10">
          <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getBadgeColor(category)}`}>
            {category}
          </span>
        </div>
        
        {/* Duration badge */}
        <div className="absolute top-3 right-3 z-10">
          <span className="inline-flex items-center bg-gray-800 bg-opacity-75 text-white px-2 py-1 rounded-full text-xs">
            <Clock size={12} className="mr-1" /> {duration}
          </span>
        </div>
        
        {/* Trending badge */}
        {isTrending && (
          <div className="absolute top-12 right-3 z-10">
            <span className="inline-flex items-center bg-red-600 text-white px-2 py-1 rounded-full text-xs">
              <ZapIcon size={12} className="mr-1" /> Trending
            </span>
          </div>
        )}
        
        {/* AI Analyzed badge */}
        {isAnalyzed && (
          <div className="absolute bottom-3 left-3 z-10">
            <span className="inline-flex items-center bg-indigo-600 bg-opacity-90 text-white px-2 py-1 rounded-full text-xs">
              <Award size={12} className="mr-1" /> AI Analyzed
            </span>
          </div>
        )}
        
        <Link href={templateUrl} className="block w-full h-full">
          <div className="absolute inset-0 bg-gray-200 flex items-center justify-center text-gray-400">
            <span>Template preview</span>
          </div>
          {image && (
            <Image 
              src={image} 
              alt={title} 
              fill 
              sizes="100%"
              className="object-cover transition-transform duration-300 group-hover:scale-105" 
            />
          )}
        </Link>
      </div>
      
      <div className="p-4">
        <Link href={templateUrl}>
          <h3 className="font-semibold text-lg text-gray-900 hover:text-blue-600 transition-colors">
            {title}
          </h3>
        </Link>
        
        <div className="flex items-center justify-between text-gray-500 text-sm mt-1">
          <span className="flex items-center">
            <TrendingUp size={14} className="mr-1" /> {views} views
          </span>
          
          {formattedEngagement && (
            <span className="flex items-center">
              <BarChart size={14} className="mr-1" /> {formattedEngagement} engagement
            </span>
          )}
        </div>
        
        {/* Template structure visualization (if available) */}
        {templateStructure && templateStructure.length > 0 && (
          <div className="mt-3 pt-3 border-t border-gray-100">
            <div className="w-full h-2 bg-gray-100 rounded-full flex overflow-hidden">
              {templateStructure.map((section, index) => {
                // Calculate width percentage based on duration
                const width = section.duration ? (section.duration / 60) * 100 : 100 / templateStructure.length;
                
                // Assign colors based on section type
                const getSectionColor = (type: string) => {
                  const colors: Record<string, string> = {
                    'Hook': 'bg-pink-500',
                    'Introduction': 'bg-blue-500',
                    'Intro': 'bg-blue-500',
                    'Content': 'bg-purple-500',
                    'Step': 'bg-indigo-500',
                    'Feature': 'bg-indigo-500',
                    'Call to Action': 'bg-green-500',
                    'CTA': 'bg-green-500',
                    'Outro': 'bg-yellow-500',
                    'Transition': 'bg-orange-400',
                  };
                  
                  // Find color by partial match
                  for (const [key, value] of Object.entries(colors)) {
                    if (type.includes(key)) {
                      return value;
                    }
                  }
                  
                  return 'bg-gray-400';
                };
                
                return (
                  <div 
                    key={index}
                    className={`h-full ${getSectionColor(section.type)}`}
                    style={{ width: `${width}%` }}
                    title={`${section.type}: ${section.duration || '?'}s`}
                  />
                );
              })}
            </div>
            <div className="mt-1 flex justify-between text-xs text-gray-500">
              <span>0s</span>
              <span>{duration}</span>
            </div>
          </div>
        )}
        
        <Link 
          href={templateUrl}
          className="mt-4 block w-full text-center bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 transition-colors"
        >
          Use template
        </Link>
      </div>
    </div>
  );
} 