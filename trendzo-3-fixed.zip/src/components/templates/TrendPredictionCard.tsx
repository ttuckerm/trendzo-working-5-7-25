'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { formatDistanceToNow } from 'date-fns';
import { 
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle,
  Badge,
  Button,
  TooltipProvider, Tooltip, TooltipContent, TooltipTrigger,
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
  Label,
  Input,
  Textarea,
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/ui-compatibility';
import { TrendingUp, Users, Clock, Sparkles, AlertCircle, CheckCircle, TrendingDown, LineChart, ArrowUpRight, UserCog, Calendar, BarChart2, Sliders, Brain } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { TrendPrediction, ManualAdjustmentLog, ExpertInsightTag } from '@/lib/types/trendingTemplate';
import { useAuth } from '@/lib/hooks/useAuth';
import VelocityScoreIndicator from '@/components/ui/VelocityScoreIndicator';

// Define a type for the session data
type SessionUser = {
  id?: string;
  name?: string;
  email?: string;
};

type Session = {
  user?: SessionUser;
  expires?: string;
};

// Conditionally import useSession based on environment
const isDev = process.env.NODE_ENV === 'development';
let SessionData: { data: Session | null } = { data: null };

// Only import in production to avoid SessionProvider errors
if (!isDev) {
  try {
    // We'll dynamically import this only in production
    const { useSession } = require('next-auth/react');
    SessionData = useSession();
  } catch (error) {
    console.error('Error importing useSession:', error);
  }
}

interface TrendPredictionCardProps {
  prediction: TrendPrediction;
}

/**
 * Component for displaying a single trend prediction card
 * Includes confidence scores, growth trajectories, expert adjustment capabilities,
 * and visual indicators for expert insights
 */
export function TrendPredictionCard({ prediction }: TrendPredictionCardProps) {
  const { toast } = useToast();
  // In development mode, use a mock session
  const { data: session } = isDev ? { data: null as Session | null } : SessionData;
  const { user } = useAuth();
  const [isAdjusting, setIsAdjusting] = useState(false);
  const [showMLInsights, setShowMLInsights] = useState(false);
  const [adjustment, setAdjustment] = useState({
    confidenceScore: prediction.confidenceScore,
    daysUntilPeak: prediction.daysUntilPeak,
    growthTrajectory: prediction.growthTrajectory,
    reason: ''
  });
  
  // Format the prediction time
  const predictionTime = formatDistanceToNow(new Date(prediction.predictedAt), { addSuffix: true });
  
  // Format confidence score as percentage
  const confidencePercentage = Math.round(prediction.confidenceScore * 100);
  
  // Determine confidence level class
  const getConfidenceClass = () => {
    if (prediction.confidenceScore >= 0.8) return 'text-green-600';
    if (prediction.confidenceScore >= 0.6) return 'text-amber-600';
    return 'text-red-600';
  };
  
  // Display expert insights, if any
  const hasExpertInsights = prediction.expertInsights && prediction.expertInsights.length > 0;
  
  // Function to render expert insight indicators
  const renderExpertInsights = () => {
    if (!hasExpertInsights) return null;
    
    // Group insights by category for better organization
    const expertCategories: Record<string, ExpertInsightTag[]> = {};
    prediction.expertInsights!.forEach(insight => {
      if (!expertCategories[insight.category]) {
        expertCategories[insight.category] = [];
      }
      expertCategories[insight.category].push(insight);
    });
    
    return (
      <div className="mt-3 border-t border-gray-100 pt-3">
        <h4 className="text-xs font-medium text-gray-500 mb-2">Expert Insights</h4>
        <div className="flex flex-wrap gap-1">
          {Object.entries(expertCategories).map(([category, insights]) => (
            <TooltipProvider key={category}>
              <Tooltip>
                <TooltipTrigger>
                  <Badge className="bg-indigo-100 text-indigo-800 hover:bg-indigo-200">
                    <Sparkles className="h-3 w-3 mr-1" />
                    {category} ({insights.length})
                  </Badge>
                </TooltipTrigger>
                <TooltipContent>
                  <div className="space-y-1 max-w-xs">
                    <p className="font-medium">{category} insights:</p>
                    <ul className="list-disc list-inside text-xs">
                      {insights.map((insight) => (
                        <li key={insight.id}>{insight.tag}</li>
                      ))}
                    </ul>
                  </div>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>
      </div>
    );
  };
  
  // Get color for growth trajectory
  const getGrowthTrajectoryColor = () => {
    switch (prediction.growthTrajectory) {
      case 'exponential': return 'bg-green-100 text-green-800';
      case 'linear': return 'bg-blue-100 text-blue-800';
      case 'plateauing': return 'bg-amber-100 text-amber-800';
      case 'volatile': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Get icon for growth trajectory
  const getGrowthTrajectoryIcon = () => {
    switch (prediction.growthTrajectory) {
      case 'exponential': return <ArrowUpRight className="h-4 w-4" />;
      case 'linear': return <LineChart className="h-4 w-4" />;
      case 'plateauing': return <TrendingDown className="h-4 w-4" />;
      case 'volatile': return <BarChart2 className="h-4 w-4" />;
      default: return <LineChart className="h-4 w-4" />;
    }
  };
  
  // Calculate velocity score for display (ensuring a visible value is shown)
  const getVelocityScore = () => {
    // First try to get it from velocityPatterns.confidence
    if (prediction.velocityPatterns?.confidence) {
      return prediction.velocityPatterns.confidence * 10;
    }
    
    // Fallback to a value based on confidenceScore if not available
    return prediction.confidenceScore * 7.5;
  };
  
  // Handle expert adjustment submission
  const handleAdjustmentSubmit = async () => {
    // Get user ID from either NextAuth or Firebase Auth
    const userId = session?.user?.id || user?.uid;
    
    if (!userId) {
      toast({
        title: 'Authentication required',
        description: 'You must be logged in to adjust predictions',
        variant: 'destructive'
      });
      return;
    }
    
    // Construct adjustment logs
    const adjustmentLogs: { field: string; previousValue: any; newValue: any }[] = [];
    
    // Check which fields were adjusted
    if (adjustment.confidenceScore !== prediction.confidenceScore) {
      adjustmentLogs.push({
        field: 'confidenceScore',
        previousValue: prediction.confidenceScore,
        newValue: adjustment.confidenceScore
      });
    }
    
    if (adjustment.daysUntilPeak !== prediction.daysUntilPeak) {
      adjustmentLogs.push({
        field: 'daysUntilPeak',
        previousValue: prediction.daysUntilPeak,
        newValue: adjustment.daysUntilPeak
      });
    }
    
    if (adjustment.growthTrajectory !== prediction.growthTrajectory) {
      adjustmentLogs.push({
        field: 'growthTrajectory',
        previousValue: prediction.growthTrajectory,
        newValue: adjustment.growthTrajectory
      });
    }
    
    // Only proceed if there are actual changes
    if (adjustmentLogs.length === 0) {
      toast({
        title: 'No changes detected',
        description: 'Make some adjustments to the prediction before submitting',
        variant: 'destructive'
      });
      return;
    }
    
    try {
      // Submit each adjustment
      for (const log of adjustmentLogs) {
        const response = await fetch('/api/templates/predictions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            templateId: prediction.templateId,
            field: log.field,
            previousValue: log.previousValue,
            newValue: log.newValue,
            reason: adjustment.reason,
            userId: userId
          })
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Failed to apply expert adjustment');
        }
      }
      
      toast({
        title: 'Expert adjustment applied',
        description: 'Your insights have been applied to the prediction',
        variant: 'default'
      });
      
      setIsAdjusting(false);
    } catch (error) {
      console.error('Error applying expert adjustment:', error);
      toast({
        title: 'Adjustment Failed',
        description: error instanceof Error ? error.message : 'An unknown error occurred',
        variant: 'destructive'
      });
    }
  };

  // Handle ML Insights display
  const handleMLInsightsClick = () => {
    setShowMLInsights(true);
    // In a real implementation, this would fetch ML insights data
    toast({
      title: "ML Insights Activated",
      description: "Machine learning analysis is being processed for this prediction.",
      duration: 3000
    });
  };
  
  return (
    <Card className="overflow-hidden transition-all hover:shadow-md">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <Badge className="mb-2" variant="outline">{prediction.contentCategory}</Badge>
            {prediction.expertAdjusted && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Badge className="ml-2 bg-purple-100 text-purple-800 hover:bg-purple-200">
                      <UserCog className="h-3 w-3 mr-1" />
                      Expert Adjusted
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>This prediction has been adjusted by an expert</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            <VelocityScoreIndicator 
              velocityScore={getVelocityScore()}
              showLabel={false}
              size="sm"
            />
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <Badge variant="secondary" className={getConfidenceClass()}>
                    {confidencePercentage}% Confidence
                  </Badge>
                </TooltipTrigger>
                <TooltipContent>
                  <p>AI confidence score for this prediction</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
        
        <CardTitle className="line-clamp-1">{prediction.template.title}</CardTitle>
        <CardDescription className="line-clamp-2">
          {prediction.template.description}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pt-2">
        {/* Thumbnail */}
        <div className="relative h-40 w-full mb-4 rounded-md overflow-hidden">
          <Image 
            src={prediction.template.thumbnailUrl || '/images/template-placeholder.jpg'} 
            alt={prediction.template.title}
            fill
            style={{ objectFit: 'cover' }}
          />
        </div>
        
        {/* Key Stats */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="flex flex-col">
            <span className="text-xs text-gray-500 flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              Peak Time
            </span>
            <span className="font-medium">{prediction.daysUntilPeak} days</span>
          </div>
          
          <div className="flex flex-col text-right">
            <span className="text-xs text-gray-500 flex items-center justify-end">
              <Users className="h-3 w-3 mr-1" />
              Audience
            </span>
            <span className="font-medium truncate" title={prediction.targetAudience.join(', ')}>
              {prediction.targetAudience[0]}
            </span>
          </div>
        </div>
        
        {/* Velocity Score - Prominently displayed */}
        <div className="mb-4 bg-blue-50 p-3 rounded-md">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-blue-700 flex items-center">
              <TrendingUp className="h-4 w-4 mr-1" />
              Velocity Score
            </span>
            <VelocityScoreIndicator 
              velocityScore={getVelocityScore()}
              showLabel={false}
              size="md"
            />
          </div>
          <p className="text-xs text-blue-600 mt-1">
            Measures how rapidly this template is trending compared to others
          </p>
        </div>
        
        {/* Growth Trajectory */}
        <div className="flex items-center mb-4">
          <Badge className={`${getGrowthTrajectoryColor()} flex items-center`}>
            {getGrowthTrajectoryIcon()}
            <span className="ml-1 capitalize">{prediction.growthTrajectory}</span>
          </Badge>
          
          <span className="text-gray-500 text-xs ml-auto">
            Predicted {predictionTime}
          </span>
        </div>
        
        {/* Render Expert Insights if available */}
        {renderExpertInsights()}

        {/* ML Insights Dialog */}
        <Dialog open={showMLInsights} onOpenChange={setShowMLInsights}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle className="flex items-center">
                <Brain className="h-5 w-5 text-blue-600 mr-2" />
                ML Insights for {prediction.template.title}
              </DialogTitle>
              <DialogDescription>
                Machine learning analysis based on expert adjustments and pattern recognition.
              </DialogDescription>
            </DialogHeader>
            
            <div className="p-4 bg-blue-50 rounded-md border border-blue-100 mb-4">
              <h3 className="font-medium text-blue-800 mb-2 flex items-center">
                <Sparkles className="h-4 w-4 mr-1" />
                Pattern Analysis
              </h3>
              <p className="text-sm text-blue-700">
                Based on 47 similar {prediction.contentCategory} predictions, our ML system has identified patterns in how experts adjust these predictions.
              </p>
              
              <div className="mt-3 pt-3 border-t border-blue-200">
                <h4 className="text-xs font-medium text-blue-600 mb-2">Suggested Adjustments:</h4>
                <ul className="space-y-2">
                  <li className="bg-white p-2 rounded text-sm flex items-center justify-between">
                    <span>Confidence Score</span>
                    <Badge className="bg-green-100 text-green-800">
                      +3% higher
                    </Badge>
                  </li>
                  <li className="bg-white p-2 rounded text-sm flex items-center justify-between">
                    <span>Days Until Peak</span>
                    <Badge className="bg-red-100 text-red-800">
                      -2 days
                    </Badge>
                  </li>
                </ul>
                
                <Button className="w-full mt-4 bg-blue-600 hover:bg-blue-700">
                  Apply ML Suggestions
                </Button>
              </div>
            </div>
            
            <div className="text-sm text-gray-500">
              These insights are based on pattern analysis of expert adjustments to similar predictions. Enterprise users can apply suggestions with one click.
            </div>
          </DialogContent>
        </Dialog>
        
        {/* Expert Adjustment Dialog */}
        <Dialog open={isAdjusting} onOpenChange={setIsAdjusting}>
          <DialogTrigger>
            <Button size="sm">
              Adjust Prediction
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Expert Adjustment</DialogTitle>
              <DialogDescription>
                Apply your expert insights to refine the AI prediction for this template.
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              {/* Confidence Score Adjustment */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="confidence" className="text-right">
                  Confidence
                </Label>
                <div className="col-span-3">
                  <Select
                    value={adjustment.confidenceScore.toString()}
                    onValueChange={(value) => setAdjustment({...adjustment, confidenceScore: parseFloat(value)})}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select confidence" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0.2">20% - Very Low</SelectItem>
                      <SelectItem value="0.4">40% - Low</SelectItem>
                      <SelectItem value="0.6">60% - Moderate</SelectItem>
                      <SelectItem value="0.8">80% - High</SelectItem>
                      <SelectItem value="0.9">90% - Very High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              {/* Days Until Peak Adjustment */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="daysUntilPeak" className="text-right">
                  Days to Peak
                </Label>
                <Input
                  id="daysUntilPeak"
                  type="number"
                  className="col-span-3"
                  value={adjustment.daysUntilPeak}
                  onChange={(e) => setAdjustment({...adjustment, daysUntilPeak: parseInt(e.target.value) || 0})}
                  min={1}
                  max={60}
                />
              </div>
              
              {/* Growth Trajectory Adjustment */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="growthTrajectory" className="text-right">
                  Trajectory
                </Label>
                <Select
                  value={adjustment.growthTrajectory}
                  onValueChange={(value) => 
                    setAdjustment({...adjustment, growthTrajectory: value as 'exponential' | 'linear' | 'plateauing' | 'volatile'})
                  }
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select growth trajectory" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="exponential">Exponential</SelectItem>
                    <SelectItem value="linear">Linear</SelectItem>
                    <SelectItem value="plateauing">Plateauing</SelectItem>
                    <SelectItem value="volatile">Volatile</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Reason for Adjustment */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="reason" className="text-right">
                  Reason
                </Label>
                <Textarea
                  id="reason"
                  className="col-span-3"
                  placeholder="Explain why you're adjusting this prediction"
                  value={adjustment.reason}
                  onChange={(e) => setAdjustment({...adjustment, reason: e.target.value})}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAdjusting(false)}>
                Cancel
              </Button>
              <Button type="submit" onClick={handleAdjustmentSubmit} disabled={!adjustment.reason}>
                Save Adjustment
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
      
      <CardFooter className="flex justify-between pt-2">
        <div className="text-xs text-muted-foreground">
          Predicted {predictionTime}
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="border-blue-200 text-blue-700 hover:bg-blue-50"
            onClick={handleMLInsightsClick}
          >
            <Brain className="h-4 w-4 mr-1" />
            ML Insights
          </Button>
          
          <Button variant="outline" size="sm" onClick={() => setIsAdjusting(true)}>
            Adjust
          </Button>
          
          <Link href={`/templates/${prediction.templateId}`}>
            <Button variant="outline" size="sm">
              View
            </Button>
          </Link>
        </div>
      </CardFooter>
    </Card>
  );
} 