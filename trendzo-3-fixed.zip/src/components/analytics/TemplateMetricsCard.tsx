import React from 'react';
import { ArrowUp, ArrowDown, Minus } from 'lucide-react';

interface MetricProps {
  label: string;
  value: string | number;
  change?: number;
  description?: string;
  icon?: React.ReactNode;
  color?: string;
}

interface TemplateMetricsCardProps {
  title: string;
  metrics: MetricProps[];
  className?: string;
}

// Helper function to format large numbers
const formatNumber = (num: number): string => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toString();
};

const TemplateMetricsCard: React.FC<TemplateMetricsCardProps> = ({
  title,
  metrics,
  className = '',
}) => {
  return (
    <div className={`rounded-lg border border-gray-200 bg-white p-6 ${className}`}>
      <h2 className="mb-4 text-lg font-semibold text-gray-900">{title}</h2>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-2">
        {metrics.map((metric, index) => (
          <div key={index} className="flex flex-col space-y-1">
            <div className="text-sm font-medium text-gray-500">{metric.label}</div>
            <div className="flex items-center gap-2">
              {metric.icon && (
                <div className={`rounded-full p-1.5 ${metric.color || 'bg-blue-100'}`}>
                  {metric.icon}
                </div>
              )}
              <div className="flex flex-col">
                <div className="text-2xl font-semibold text-gray-900">
                  {typeof metric.value === 'number' ? formatNumber(metric.value as number) : metric.value}
                </div>
                {metric.change !== undefined && (
                  <div className="flex items-center text-sm">
                    {metric.change > 0 ? (
                      <div className="flex items-center text-green-600">
                        <ArrowUp size={14} />
                        <span>{metric.change}%</span>
                      </div>
                    ) : metric.change < 0 ? (
                      <div className="flex items-center text-red-600">
                        <ArrowDown size={14} />
                        <span>{Math.abs(metric.change)}%</span>
                      </div>
                    ) : (
                      <div className="flex items-center text-gray-500">
                        <Minus size={14} />
                        <span>0%</span>
                      </div>
                    )}
                    <span className="ml-1 text-gray-500">vs avg</span>
                  </div>
                )}
                {metric.description && (
                  <div className="text-xs text-gray-500">{metric.description}</div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TemplateMetricsCard; 