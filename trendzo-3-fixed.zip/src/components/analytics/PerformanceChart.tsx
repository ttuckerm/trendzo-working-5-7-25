"use client"

import React from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

type DataPoint = {
  date: string;
  value: number;
  benchmark?: number;
};

interface PerformanceChartProps {
  data: DataPoint[];
  title: string;
  valueLabel: string;
  color?: string;
  benchmarkLabel?: string;
  benchmarkColor?: string;
  showBenchmark?: boolean;
  formatValue?: (value: number) => string;
  className?: string;
}

const PerformanceChart: React.FC<PerformanceChartProps> = ({
  data,
  title,
  valueLabel,
  color = '#3b82f6', // blue-500
  benchmarkLabel = 'Industry Average',
  benchmarkColor = '#9ca3af', // gray-400
  showBenchmark = true,
  formatValue,
  className = '',
}) => {
  // Default formatter just returns the value
  const defaultFormatter = (value: number) => value.toString();
  const formatter = formatValue || defaultFormatter;

  return (
    <div className={`rounded-lg border border-gray-200 bg-white p-6 ${className}`}>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-900">{title}</h2>
      </div>
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={data}
            margin={{
              top: 10,
              right: 30,
              left: 0,
              bottom: 0,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis 
              dataKey="date" 
              tickLine={false}
              axisLine={false}
              tick={{ fill: '#94a3b8', fontSize: 12 }}
            />
            <YAxis 
              tickFormatter={formatter}
              tickLine={false}
              axisLine={false}
              tick={{ fill: '#94a3b8', fontSize: 12 }}
            />
            <Tooltip 
              formatter={(value: number) => [formatter(value), valueLabel]}
              labelFormatter={(label) => `Date: ${label}`}
              contentStyle={{ 
                borderRadius: '6px', 
                border: '1px solid #e2e8f0',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
              }}
            />
            <Legend />
            <Area
              type="monotone"
              dataKey="value"
              stroke={color}
              fill={color}
              fillOpacity={0.1}
              name={valueLabel}
              strokeWidth={2}
              activeDot={{ r: 6 }}
            />
            {showBenchmark && (
              <Area
                type="monotone"
                dataKey="benchmark"
                stroke={benchmarkColor}
                fill={benchmarkColor}
                fillOpacity={0.05}
                name={benchmarkLabel}
                strokeDasharray="5 5"
                strokeWidth={2}
                dot={false}
              />
            )}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default PerformanceChart; 