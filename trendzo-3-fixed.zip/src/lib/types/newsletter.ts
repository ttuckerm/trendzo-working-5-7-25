/**
 * Types for Newsletter Integration functionality
 */

/**
 * Represents a template link for newsletter
 */
export interface NewsletterTemplateLink {
  id: string;
  templateId: string;
  title: string;
  description?: string;
  createdAt: string;
  expiresAt?: string;
  createdBy: string;
  token: string;
  shortCode: string;
  fullUrl: string;
  clicks: number;
  conversions: number;
  lastClicked?: string;
  
  // Tracking and context
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  utm_term?: string;
  utm_content?: string;
  
  // Additional context data to pass to the editor
  editorContext?: Record<string, any>;
  
  // Whether the link has been used in a newsletter
  usedInNewsletter: boolean;
  newsletterId?: string;
  newsletterIssue?: string;
  
  // Expert attribution
  expertCreated: boolean;
  expertId?: string;
  expertNote?: string;
}

/**
 * Parameters for creating a new newsletter template link
 */
export interface CreateNewsletterLinkParams {
  templateId: string;
  title: string;
  description?: string;
  expiresAt?: string;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  utm_term?: string;
  utm_content?: string;
  editorContext?: Record<string, any>;
  expertCreated?: boolean;
  expertId?: string;
  expertNote?: string;
}

/**
 * Newsletter click event for analytics
 */
export interface NewsletterClickEvent {
  id: string;
  linkId: string;
  userId?: string;
  timestamp: string;
  ipAddress?: string;
  userAgent?: string;
  referrer?: string;
  converted: boolean;
  conversionType?: 'view' | 'edit' | 'save' | 'publish';
  conversionTimestamp?: string;
  sessionDuration?: number;
}

/**
 * Newsletter analytics summary
 */
export interface NewsletterAnalytics {
  linkId: string;
  templateId: string;
  totalClicks: number;
  uniqueClicks: number;
  conversionRate: number;
  totalConversions: number;
  conversionsByType: Record<string, number>;
  clicksByDay: Array<{date: string, count: number}>;
  avgSessionDuration: number;
  topReferrers: Array<{referrer: string, count: number}>;
  expertCreated: boolean;
}

/**
 * Redirect result for newsletter links
 */
export interface NewsletterRedirectResult {
  success: boolean;
  redirectUrl: string;
  templateId?: string;
  editorContext?: Record<string, any>;
  requiresAuth: boolean;
  error?: string;
  linkId?: string;
}

/**
 * Current user context for newsletter redirects
 */
export interface NewsletterUserContext {
  isAuthenticated: boolean;
  userId?: string;
  email?: string;
  name?: string;
  isPremium: boolean;
  lastLoginAt?: string;
} 