/**
 * Type definitions for TikTok data structures used in the ETL process
 */

/**
 * Represents a TikTok video with all relevant metadata
 */
export interface TikTokVideo {
  id: string;
  desc: string;
  createTime: number;
  author: {
    id: string;
    uniqueId: string;
    nickname: string;
    avatarThumb: string;
    signature?: string;
    verified?: boolean;
  };
  music?: {
    id: string;
    title: string;
    authorName?: string;
    playUrl?: string;
  };
  stats: {
    diggCount: number;
    shareCount: number;
    commentCount: number;
    playCount: number;
  };
  video: {
    id: string;
    duration: number;
    ratio: string;
    cover?: string;
    dynamicCover?: string; 
    playAddr?: string;
    downloadAddr?: string;
    height?: number;
    width?: number;
  };
  hashtags?: Array<{
    id: string;
    name: string;
    title: string;
  }>;
  challenges?: string[];
  trends?: string[];
  effectIds?: string[];
}

/**
 * Position data for text overlay on a template
 */
export interface TextPosition {
  x: number;
  y: number;
  width?: number; 
  height?: number;
  alignment?: 'left' | 'center' | 'right';
}

/**
 * Style information for text overlay
 */
export interface TextStyle {
  fontSize: number;
  fontFamily?: string;
  fontWeight?: string | number;
  color: string;
  backgroundColor?: string;
  opacity?: number;
  shadow?: boolean;
  outline?: boolean;
  animation?: string;
}

/**
 * Represents a text overlay in a template section
 */
export interface TextOverlay {
  id: string;
  text: string;
  position: TextPosition;
  style: TextStyle;
  duration?: number;
  startTime?: number;
}

/**
 * Represents a section of a template (intro, content, outro)
 */
export interface TemplateSection {
  id: string;
  type: 'intro' | 'content' | 'outro';
  duration: number;
  startTime: number;
  endTime: number;
  textOverlays: TextOverlay[];
  transitions?: string[];
  effects?: string[];
}

/**
 * Represents a template created from a TikTok video
 */
export interface Template {
  id: string;
  title: string;
  description: string;
  sourceVideoId: string;
  sourceAuthor: {
    id: string;
    username: string;
  };
  duration: number;
  thumbnailUrl?: string;
  sections: TemplateSection[];
  category: string;
  tags: string[];
  stats: {
    views: number;
    uses: number;
    likes: number;
    shares: number;
    createdAt: number;
    updatedAt: number;
  };
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  trendscore?: number;
}

/**
 * Options for the ETL process
 */
export interface ETLOptions {
  maxItems?: number;
  categories?: string[];
  minEngagement?: number;
  skipExisting?: boolean;
  forceUpdate?: boolean;
} 