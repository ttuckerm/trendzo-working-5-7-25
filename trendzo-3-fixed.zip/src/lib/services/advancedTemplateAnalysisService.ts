import { TikTokVideo, TemplateSection, TemplateAnalysis, TrendingTemplate } from '@/lib/types/trendingTemplate';
import { templateAnalysisService } from './templateAnalysisService';
import { trendingTemplateService } from './trendingTemplateService';
import { v4 as uuidv4 } from 'uuid';

/**
 * Advanced service for analyzing TikTok videos using Claude AI
 * This service builds on the basic templateAnalysisService by adding
 * AI-powered analysis capabilities for deeper insights
 */
export const advancedTemplateAnalysisService = {
  /**
   * Analyze video metadata and content using Claude AI
   * @param video TikTok video object to analyze
   * @returns Enhanced template analysis with AI insights
   */
  async analyzeVideoWithAI(video: TikTokVideo): Promise<{
    templateSections: TemplateSection[];
    category: string;
    analysis: TemplateAnalysis;
  }> {
    try {
      // Get basic template sections from the existing service
      const templateSections = templateAnalysisService.analyzeVideoForTemplates(video);
      const category = templateAnalysisService.categorizeVideo(video);
      
      // Use AI to enhance the analysis
      const aiAnalysis = await this.performClaudeAnalysis(video, templateSections);
      
      return {
        templateSections: aiAnalysis.enhancedSections || templateSections,
        category: aiAnalysis.refinedCategory || category,
        analysis: {
          templateId: '', // Will be set when saved to database
          videoId: video.id,
          estimatedSections: aiAnalysis.enhancedSections || templateSections,
          detectedElements: aiAnalysis.detectedElements || {
            hasCaption: video.text.length > 0,
            hasCTA: this.detectCTA(video.text),
            hasProductDisplay: false, // Requires visual analysis
            hasTextOverlay: templateSections.some(s => s.textOverlays.length > 0),
            hasVoiceover: false, // Requires audio analysis
            hasBgMusic: false, // Requires audio analysis
          },
          effectiveness: {
            engagementRate: this.calculateEngagementRate(video),
            // Other metrics would be calculated over time
          },
          engagementInsights: aiAnalysis.engagementInsights || '',
          similarityPatterns: aiAnalysis.similarityPatterns || ''
        }
      };
    } catch (error) {
      console.error('Error in AI analysis:', error);
      
      // Fallback to basic analysis
      const templateSections = templateAnalysisService.analyzeVideoForTemplates(video);
      const category = templateAnalysisService.categorizeVideo(video);
      
      return {
        templateSections,
        category,
        analysis: {
          templateId: '',
          videoId: video.id,
          estimatedSections: templateSections,
          detectedElements: {
            hasCaption: video.text.length > 0,
            hasCTA: this.detectCTA(video.text),
            hasProductDisplay: false,
            hasTextOverlay: templateSections.some(s => s.textOverlays.length > 0),
            hasVoiceover: false,
            hasBgMusic: false,
          },
          effectiveness: {
            engagementRate: this.calculateEngagementRate(video),
          }
        }
      };
    }
  },
  
  /**
   * Use Claude AI to perform advanced analysis on the video
   * @param video TikTok video to analyze
   * @param templateSections Initial template sections
   * @returns Enhanced analysis data
   */
  async performClaudeAnalysis(video: TikTokVideo, templateSections: TemplateSection[]) {
    try {
      // Prepare prompt for Claude
      const prompt = this.generateAnalysisPrompt(video, templateSections);
      
      // Call Claude AI API
      const response = await fetch('/api/anthropic/analyze-template', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt }),
      });
      
      if (!response.ok) {
        throw new Error(`Claude API responded with status ${response.status}`);
      }
      
      const data = await response.json();
      return this.parseClaudeResponse(data.text);
    } catch (error) {
      console.error('Error calling Claude AI:', error);
      // Return empty enhancement data to fall back to basic analysis
      return {};
    }
  },
  
  /**
   * Generate a prompt for Claude AI to analyze the video
   */
  generateAnalysisPrompt(video: TikTokVideo, templateSections: TemplateSection[]): string {
    // Calculate engagement metrics to include in the prompt
    const totalEngagements = video.stats.diggCount + video.stats.commentCount + video.stats.shareCount;
    const engagementRate = totalEngagements / Math.max(1, video.stats.playCount) * 100;
    const likeToViewRatio = video.stats.diggCount / Math.max(1, video.stats.playCount) * 100;
    const commentToViewRatio = video.stats.commentCount / Math.max(1, video.stats.playCount) * 100;
    const shareToViewRatio = video.stats.shareCount / Math.max(1, video.stats.playCount) * 100;
    
    // Extract text patterns and hashtags for better context
    const captionWords = video.text.split(/\s+/).length;
    const captionLength = video.text.length;
    const captionDensity = captionWords > 0 ? captionLength / captionWords : 0;
    const hashtagCount = (video.hashtags || []).length;
    
    return `
      You are an expert TikTok template analyst. Analyze this TikTok video data and identify template patterns, structure, engagement factors, and viral potential.
      
      VIDEO INFORMATION:
      Description: ${video.text}
      Duration: ${video.videoMeta?.duration || 0} seconds
      Hashtags: ${(video.hashtags || []).join(', ')}
      Author: ${video.authorMeta.nickname} (Verified: ${video.authorMeta.verified ? 'Yes' : 'No'})
      
      ENGAGEMENT METRICS:
      Views: ${video.stats.playCount.toLocaleString()}
      Likes: ${video.stats.diggCount.toLocaleString()} (${likeToViewRatio.toFixed(2)}% of views)
      Comments: ${video.stats.commentCount.toLocaleString()} (${commentToViewRatio.toFixed(2)}% of views)
      Shares: ${video.stats.shareCount.toLocaleString()} (${shareToViewRatio.toFixed(2)}% of views)
      Total Engagement Rate: ${engagementRate.toFixed(2)}%
      
      TEXT ANALYSIS:
      Caption Word Count: ${captionWords}
      Caption Length: ${captionLength} characters
      Word Density: ${captionDensity.toFixed(2)} characters per word
      Hashtag Count: ${hashtagCount}
      
      CURRENT TEMPLATE STRUCTURE:
      ${JSON.stringify(templateSections, null, 2)}
      
      Based on this data, provide a comprehensive template analysis with the following components:
      
      1. ENHANCED TEMPLATE SECTIONS:
         - Identify all distinct sections (hook, intro, main content, transitions, CTA, outro)
         - Provide exact timestamps for each section (start time and duration)
         - Describe each section's purpose and content type
         - Note any special effects, transitions, or patterns used in each section
      
      2. TEMPLATE CATEGORIZATION:
         - Identify the primary content category (e.g., tutorial, dance, comedy, product)
         - Subcategorize by specific template type (e.g., "How-To Tutorial", "Transformation Reveal")
         - Note industry or niche relevance (e.g., beauty, fitness, finance)
         - Estimate the template trend age (new, established, or classic pattern)
      
      3. ENGAGEMENT ANALYSIS:
         - Explain why this video might be engaging (specific elements that drive views)
         - Identify hook strength and attention retention factors
         - Note call-to-action effectiveness
         - Highlight any viral triggers or emotional elements
      
      4. VIRALITY POTENTIAL:
         - Rate the template's viral potential on a scale of 1-10
         - Identify specific elements that could make this template spread
         - Note any trending elements leveraged in the content
         - Suggest optimizations to increase virality
      
      5. TEMPLATE OPTIMIZATION RECOMMENDATIONS:
         - Suggest specific improvements to each section
         - Identify missing elements that could boost engagement
         - Note timing adjustments that could improve retention
         - Recommend pattern variations for different niches
      
      Format your response as valid JSON with these keys:
      {
        "enhancedSections": [
          {
            "id": "string",
            "type": "string",
            "startTime": number,
            "duration": number,
            "purpose": "string",
            "contentDescription": "string"
          }
        ],
        "detectedElements": {
          "hasCaption": boolean,
          "hasCTA": boolean,
          "hasProductDisplay": boolean,
          "hasTextOverlay": boolean,
          "hasVoiceover": boolean,
          "hasBgMusic": boolean,
          "hasTransition": boolean,
          "hasTrending": boolean
        },
        "refinedCategory": {
          "primary": "string",
          "template": "string",
          "industry": "string",
          "trendAge": "string"
        },
        "engagementInsights": "string",
        "viralityFactors": {
          "score": number,
          "strengths": ["string"],
          "weaknesses": ["string"],
          "optimizations": ["string"]
        },
        "similarityPatterns": "string"
      }
      
      Ensure all JSON is properly formatted and valid. Focus on extracting actionable insights that would help content creators understand what makes this template effective.
    `;
  },
  
  /**
   * Parse Claude AI's response into structured data
   */
  parseClaudeResponse(responseText: string): any {
    try {
      // First attempt: Try to parse the entire response as JSON directly
      try {
        return JSON.parse(responseText);
      } catch (directParseError) {
        console.log('Direct JSON parse failed, trying alternative methods');
      }
      
      // Second attempt: Look for JSON code blocks (Claude often wraps JSON in markdown)
      const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/) || 
                        responseText.match(/```\n([\s\S]*?)\n```/) ||
                        responseText.match(/{[\s\S]*?}/);
      
      if (jsonMatch) {
        // Parse the JSON from the matched block, cleaning up any markdown formatting
        const jsonContent = jsonMatch[0].replace(/```json\n|```\n|```/g, '');
        try {
          return JSON.parse(jsonContent);
        } catch (blockParseError) {
          console.error('Failed to parse JSON from code block:', blockParseError);
        }
      }
      
      // Third attempt: Try to extract sections directly
      if (responseText.includes('"enhancedSections"') || 
          responseText.includes('"detectedElements"') ||
          responseText.includes('"viralityFactors"')) {
        
        // Look for a complete JSON object 
        const potentialMatch = responseText.match(/{[\s\S]*?enhancedSections[\s\S]*?}/);
        if (potentialMatch) {
          try {
            return JSON.parse(potentialMatch[0]);
          } catch (sectionParseError) {
            console.error('Failed to parse JSON with enhancedSections:', sectionParseError);
          }
        }
        
        // If we can't find a complete JSON object, try to reconstruct one from the content
        try {
          const fullJson = `{${responseText.split('{')[1].split('}').slice(0, -1).join('}')}}`; 
          return JSON.parse(fullJson);
        } catch (reconstructError) {
          console.error('Failed to reconstruct JSON:', reconstructError);
        }
      }
      
      // Final fallback: Extract any JSON-like objects, even if partial
      const jsonPattern = /{[^{}]*({[^{}]*}[^{}]*)*}/g;
      const jsonMatches = responseText.match(jsonPattern);
      
      if (jsonMatches && jsonMatches.length > 0) {
        // Try each match until one parses successfully
        for (const match of jsonMatches) {
          try {
            return JSON.parse(match);
          } catch (matchError) {
            // Continue to the next match
          }
        }
      }
      
      // If we get here, we couldn't parse any JSON
      console.warn('Could not parse valid JSON from Claude response, returning empty object');
      console.debug('Original response:', responseText);
      return {};
    } catch (error) {
      console.error('Error parsing Claude response:', error);
      return {};
    }
  },
  
  /**
   * Identify templates with similar patterns
   * @param templateId ID of the template to find similarities for
   * @param limit Maximum number of similar templates to return
   */
  async findSimilarTemplates(templateId: string, limit = 10): Promise<TrendingTemplate[]> {
    try {
      // Get the template we want to compare
      const template = await trendingTemplateService.getTrendingTemplateById(templateId);
      if (!template) {
        throw new Error(`Template with ID ${templateId} not found`);
      }
      
      // Get all templates in the same category
      const categoryTemplates = await trendingTemplateService.getTrendingTemplatesByCategory(
        template.category, 
        50 // Get more to increase chance of finding similar ones
      );
      
      // Filter out the current template
      const otherTemplates = categoryTemplates.filter(t => t.id !== templateId);
      
      // Simple similarity check based on duration and structure
      const similarityScores = otherTemplates.map(t => ({
        template: t,
        score: this.calculateTemplateSimilarity(template, t)
      }));
      
      // Sort by similarity score descending
      similarityScores.sort((a, b) => b.score - a.score);
      
      // Return the top matches
      return similarityScores.slice(0, limit).map(s => s.template);
    } catch (error) {
      console.error('Error finding similar templates:', error);
      return [];
    }
  },
  
  /**
   * Calculate similarity score between two templates
   * Higher score = more similar
   */
  calculateTemplateSimilarity(template1: TrendingTemplate, template2: TrendingTemplate): number {
    let score = 0;
    
    // Duration similarity (max 20 points)
    const durationDiff = Math.abs(template1.metadata.duration - template2.metadata.duration);
    score += Math.max(0, 20 - (durationDiff * 2));
    
    // Section structure similarity (max 40 points)
    const sections1 = template1.templateStructure;
    const sections2 = template2.templateStructure;
    
    if (sections1.length === sections2.length) {
      score += 10;
      
      // Compare section types
      let matchingTypes = 0;
      for (let i = 0; i < Math.min(sections1.length, sections2.length); i++) {
        if (sections1[i].type === sections2[i].type) {
          matchingTypes++;
        }
      }
      score += 30 * (matchingTypes / Math.max(sections1.length, sections2.length));
    }
    
    // Hashtag similarity (max 20 points)
    const hashtags1 = template1.metadata.hashtags || [];
    const hashtags2 = template2.metadata.hashtags || [];
    
    const commonHashtags = hashtags1.filter(tag => hashtags2.includes(tag)).length;
    score += 20 * (commonHashtags / Math.max(hashtags1.length, hashtags2.length, 1));
    
    // Engagement similarity (max 20 points)
    const engagementDiff = Math.abs(
      template1.stats.engagementRate - template2.stats.engagementRate
    );
    score += Math.max(0, 20 - (engagementDiff * 10));
    
    return score;
  },
  
  /**
   * Track velocity of template popularity growth
   * @param templateId Template to analyze
   * @returns Growth metrics
   */
  async trackTemplateVelocity(templateId: string): Promise<{
    dailyGrowth: number;
    weeklyGrowth: number;
    velocityScore: number;
  }> {
    try {
      const template = await trendingTemplateService.getTrendingTemplateById(templateId);
      if (!template) {
        throw new Error(`Template with ID ${templateId} not found`);
      }
      
      const dailyViews = template.trendData.dailyViews;
      const dates = Object.keys(dailyViews).sort();
      
      if (dates.length < 2) {
        return { 
          dailyGrowth: 0, 
          weeklyGrowth: template.trendData.growthRate,
          velocityScore: 0 
        };
      }
      
      // Calculate daily growth (last day)
      const lastDate = dates[dates.length - 1];
      const prevDate = dates[dates.length - 2];
      
      const lastValue = dailyViews[lastDate] || 0;
      const prevValue = dailyViews[prevDate] || 0;
      
      let dailyGrowth = 0;
      if (prevValue > 0) {
        dailyGrowth = ((lastValue - prevValue) / prevValue) * 100;
      }
      
      // Weekly growth is already calculated in the template
      const weeklyGrowth = template.trendData.growthRate;
      
      // Calculate velocity score (combination of growth rate and acceleration)
      // Higher score = faster trending
      let velocityScore = (dailyGrowth + weeklyGrowth) / 2;
      
      // Add bonus for acceleration (if daily growth > weekly growth)
      if (dailyGrowth > weeklyGrowth) {
        velocityScore += (dailyGrowth - weeklyGrowth) / 2;
      }
      
      return { dailyGrowth, weeklyGrowth, velocityScore };
    } catch (error) {
      console.error('Error tracking template velocity:', error);
      return { dailyGrowth: 0, weeklyGrowth: 0, velocityScore: 0 };
    }
  },
  
  /**
   * Calculate engagement rate for a video
   */
  calculateEngagementRate(video: TikTokVideo): number {
    const totalViews = video.stats.playCount || 1;
    return (
      (video.stats.diggCount + video.stats.commentCount + video.stats.shareCount) / 
      totalViews
    ) * 100;
  },
  
  /**
   * Simple detection for call-to-action text
   */
  detectCTA(text: string): boolean {
    const ctaPatterns = [
      'follow', 'subscribe', 'like', 'comment', 'share',
      'click', 'link in bio', 'check out', 'try', 'get',
      'buy', 'shop', 'order', 'sign up', 'join',
      'learn more', 'find out', 'discover', 'visit', 'contact'
    ];
    
    return ctaPatterns.some(pattern => 
      text.toLowerCase().includes(pattern)
    );
  },
  
  /**
   * Integrate expert insights with AI analysis
   * @param templateId Template ID
   * @param aiAnalysis Original AI analysis result
   * @param expertInsights Expert insights to incorporate
   * @returns Enhanced analysis with expert insights
   */
  async enhanceWithExpertInsights(
    templateId: string,
    aiAnalysis: any,
    expertInsights: any
  ) {
    try {
      if (!expertInsights) {
        return aiAnalysis; // No expert insights to incorporate
      }
      
      // Create a deep copy of the analysis to avoid modifying the original
      const enhancedAnalysis = JSON.parse(JSON.stringify(aiAnalysis));
      
      // Add expert confidence indicators
      enhancedAnalysis.expertEnhanced = true;
      enhancedAnalysis.expertConfidence = this.calculateExpertConfidence(expertInsights);
      
      // Log this enhancement for auditing and improvement tracking
      console.log(`Analysis for template ${templateId} enhanced with expert insights`);
      
      // Apply expert tags to refine template categorization
      if (expertInsights.tags && expertInsights.tags.length > 0) {
        // Calculate weighted categories based on expert tags
        const categoryWeights: Record<string, number> = {};
        
        expertInsights.tags.forEach((tag: any) => {
          if (tag.category === 'content' || tag.category === 'trend') {
            const weight = tag.confidence || 0.7;
            categoryWeights[tag.tag] = (categoryWeights[tag.tag] || 0) + weight;
          }
        });
        
        // Find the highest weighted category
        let highestWeight = 0;
        let primaryCategory = '';
        
        Object.entries(categoryWeights).forEach(([category, weight]) => {
          if (weight > highestWeight) {
            highestWeight = weight;
            primaryCategory = category;
          }
        });
        
        // Adjust the categorization if we have a strong expert opinion
        if (primaryCategory && highestWeight > 0.8) {
          if (enhancedAnalysis.refinedCategory) {
            enhancedAnalysis.refinedCategory.expertSuggested = primaryCategory;
          } else {
            enhancedAnalysis.refinedCategory = {
              primary: aiAnalysis.refinedCategory?.primary || 'Uncategorized',
              expertSuggested: primaryCategory
            };
          }
        }
      }
      
      // Incorporate expert notes into engagement insights
      if (expertInsights.notes) {
        if (Array.isArray(enhancedAnalysis.engagementInsights)) {
          enhancedAnalysis.engagementInsights.unshift(`Expert insight: ${expertInsights.notes}`);
        } else if (typeof enhancedAnalysis.engagementInsights === 'string') {
          enhancedAnalysis.engagementInsights = [
            `Expert insight: ${expertInsights.notes}`,
            enhancedAnalysis.engagementInsights
          ];
        } else {
          enhancedAnalysis.engagementInsights = [`Expert insight: ${expertInsights.notes}`];
        }
      }
      
      // Adjust virality factors based on expert rating
      if (expertInsights.performanceRating && enhancedAnalysis.viralityFactors) {
        // Map 1-5 rating to 0.2-1.0 scale
        const expertRatingFactor = expertInsights.performanceRating / 5;
        
        // Blend AI score with expert rating (60% AI, 40% expert)
        const originalScore = enhancedAnalysis.viralityFactors.score || 5;
        const blendedScore = (originalScore * 0.6) + (expertRatingFactor * 10 * 0.4);
        
        enhancedAnalysis.viralityFactors.score = Math.min(10, Math.max(1, blendedScore));
        enhancedAnalysis.viralityFactors.expertAdjusted = true;
      }
      
      // Add recommended uses from experts
      if (expertInsights.recommendedUses && expertInsights.recommendedUses.length > 0) {
        enhancedAnalysis.recommendedUses = expertInsights.recommendedUses;
      }
      
      // Add audience recommendations from experts
      if (expertInsights.audienceRecommendation && expertInsights.audienceRecommendation.length > 0) {
        enhancedAnalysis.targetAudience = expertInsights.audienceRecommendation;
      }
      
      return enhancedAnalysis;
    } catch (error) {
      console.error('Error enhancing analysis with expert insights:', error);
      // Return original analysis if enhancement fails
      return aiAnalysis;
    }
  },
  
  /**
   * Calculate an overall confidence score based on expert insights
   * @param expertInsights Expert insights object
   * @returns Confidence score between 0-1
   */
  calculateExpertConfidence(expertInsights: any): number {
    if (!expertInsights) return 0;
    
    let confidenceScore = 0;
    let factorsConsidered = 0;
    
    // Calculate average confidence from tags
    if (expertInsights.tags && expertInsights.tags.length > 0) {
      const tagConfidenceSum = expertInsights.tags.reduce(
        (sum: number, tag: any) => sum + (tag.confidence || 0.7), 
        0
      );
      confidenceScore += tagConfidenceSum / expertInsights.tags.length;
      factorsConsidered++;
    }
    
    // Consider performance rating (convert 1-5 scale to 0-1)
    if (expertInsights.performanceRating) {
      confidenceScore += expertInsights.performanceRating / 5;
      factorsConsidered++;
    }
    
    // Consider the presence of notes (having notes increases confidence)
    if (expertInsights.notes && expertInsights.notes.length > 30) {
      confidenceScore += 0.8; // Detailed notes increase confidence
      factorsConsidered++;
    } else if (expertInsights.notes) {
      confidenceScore += 0.5; // Some notes are better than none
      factorsConsidered++;
    }
    
    // Consider recommended uses
    if (expertInsights.recommendedUses && expertInsights.recommendedUses.length > 0) {
      confidenceScore += Math.min(0.9, expertInsights.recommendedUses.length * 0.2);
      factorsConsidered++;
    }
    
    // Calculate average confidence score
    return factorsConsidered > 0 
      ? Math.min(1, confidenceScore / factorsConsidered)
      : 0;
  }
}; 