import { ApifyClient } from 'apify-client';
import { ETLError, logETLEvent, ETLLogLevel } from '@/lib/utils/etlLogger';

// Initialize the ApifyClient with API token
const client = new ApifyClient({
  token: process.env.APIFY_API_TOKEN || '',
});

// Log API token status for debugging
console.log('APIFY_API_TOKEN status:', process.env.APIFY_API_TOKEN ? 'Set' : 'Not set');

if (!process.env.APIFY_API_TOKEN) {
  console.warn('Warning: APIFY_API_TOKEN is not set. TikTok scraping will likely fail.');
}

// Default parameters for TikTok scraper
const DEFAULT_SCRAPER_SETTINGS = {
  search: '',
  mode: 'trending',
  proxy: {
    useApifyProxy: true,
    apifyProxyGroups: ['RESIDENTIAL'],
  },
  maxItems: 50,
  customMapFunction: `
    ({ data, customData }) => {
      return data.map(item => ({
        id: item.id,
        text: item.desc,
        createTime: item.createTime,
        authorMeta: {
          id: item.authorMeta?.id,
          name: item.authorMeta?.name,
          nickname: item.authorMeta?.nickname,
          verified: item.authorMeta?.verified
        },
        videoMeta: {
          height: item.videoMeta?.height,
          width: item.videoMeta?.width,
          duration: item.videoMeta?.duration,
        },
        hashtags: item.hashtags?.map(tag => tag.name) || [],
        stats: {
          commentCount: item.stats?.commentCount,
          diggCount: item.stats?.diggCount,
          playCount: item.stats?.playCount,
          shareCount: item.stats?.shareCount,
        },
        videoUrl: item.videoUrl,
        webVideoUrl: item.webVideoUrl,
      }));
    }`
};

// Maximum number of retry attempts
const MAX_RETRY_COUNT = 3;

// Service for TikTok scraping
export const apifyService = {
  /**
   * Run the TikTok scraper with the given settings and retry on failure
   * @param options Override default scraper settings
   * @returns The run output
   */
  async scrapeTrending(options = {}) {
    console.log('Starting TikTok scraper run with options:', JSON.stringify(options));
    
    // Track retry attempts
    let retryCount = 0;
    let lastError = null;
    
    while (retryCount <= MAX_RETRY_COUNT) {
      try {
        // If this is a retry, log it
        if (retryCount > 0) {
          console.log(`Retry attempt ${retryCount} of ${MAX_RETRY_COUNT}. Last error: ${lastError?.message}`);
        }
        
        // Merge default settings with any provided options
        const input = {
          ...DEFAULT_SCRAPER_SETTINGS,
          ...options,
        };
        
        // Add timestamp to track freshness of data
        input.timestamp = new Date().toISOString();
        
        // Start the TikTok Scraper actor
        const actorId = 'kEBFCPLmS2ffJN9wC'; // TikTok Scraper actor ID
        console.log(`Using Apify actor: ${actorId}`);
        
        const run = await client.actor(actorId).call(input);
        
        // Wait for the run to finish
        console.log(`Run started with ID: ${run.id}`);
        const { items } = await client.dataset(run.defaultDatasetId).listItems();
        console.log(`Scraper finished with ${items.length} items`);
        
        // Validate the data
        this.validateScrapedData(items);
        
        return items;
      } catch (error) {
        // Capture the error for logging in retry attempts
        lastError = error;
        
        // Log the error
        console.error(`Error running TikTok scraper (attempt ${retryCount + 1}/${MAX_RETRY_COUNT + 1}):`, error);
        
        // Check if we should retry
        if (retryCount >= MAX_RETRY_COUNT) {
          console.error(`Maximum retry attempts (${MAX_RETRY_COUNT}) reached. Last error:`, lastError);
          throw error;
        }
        
        // Exponential backoff
        const delay = Math.pow(2, retryCount) * 1000;
        console.log(`Waiting ${delay}ms before retry...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        
        retryCount++;
      }
    }
    
    // This should never be reached due to throw in the catch block
    throw new Error('Unexpected error in scraper retry loop');
  },
  
  /**
   * Validate the scraped data from Apify
   * @param items The items returned from Apify
   * @throws Error if validation fails
   */
  validateScrapedData(items) {
    if (!items || !Array.isArray(items)) {
      throw new Error('Apify returned invalid data format (not an array)');
    }
    
    if (items.length === 0) {
      throw new Error('Apify returned empty results');
    }
    
    // Check for required fields in the first item
    const requiredFields = ['id', 'text', 'authorMeta', 'videoMeta', 'stats'];
    const firstItem = items[0];
    
    for (const field of requiredFields) {
      if (!firstItem[field]) {
        throw new Error(`Scraped data missing required field: ${field}`);
      }
    }
    
    // Count how many items have valid data
    const validItems = items.filter(item => 
      item.id && 
      item.videoMeta && 
      item.videoMeta.duration && 
      item.stats && 
      item.stats.playCount
    );
    
    const validPercentage = (validItems.length / items.length) * 100;
    
    // Log validation results
    console.log(`Data validation: ${validItems.length}/${items.length} (${validPercentage.toFixed(1)}%) items valid`);
    
    // If less than 30% of items are valid, throw an error
    if (validPercentage < 30) {
      throw new Error(`Data quality too low: only ${validPercentage.toFixed(1)}% of items have valid data`);
    }
  },
  
  /**
   * Search for TikTok videos by hashtag
   * @param hashtag The hashtag to search for (without #)
   * @param limit Max number of items to fetch
   * @returns The scraped items
   */
  async scrapeByHashtag(hashtag: string, limit = 30) {
    console.log(`Scraping TikTok videos by hashtag: ${hashtag} (limit: ${limit})`);
    
    return this.scrapeTrending({
      search: hashtag,
      mode: 'hashtag',
      maxItems: limit,
    });
  },
  
  /**
   * Search for TikTok trending videos in a specific category
   * @param category Category to search for
   * @param limit Max number of items to fetch
   * @returns The scraped items
   */
  async scrapeByCategory(category: string, limit = 30) {
    console.log(`Scraping TikTok trending videos in category: ${category} (limit: ${limit})`);
    
    return this.scrapeTrending({
      search: category,
      mode: 'trending',
      maxItems: limit,
    });
  },
  
  /**
   * Get the status of the Apify API
   * @returns The API status
   */
  async getApifyStatus() {
    try {
      const user = await client.user().get();
      return {
        status: 'ok',
        subscription: user.subscription,
        availableMemory: user.availableMemory,
        availableCpu: user.availableCpu,
        rateLimitState: user.rateLimitState
      };
    } catch (error) {
      console.error('Error checking Apify status:', error);
      
      return {
        status: 'error',
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }
}; 