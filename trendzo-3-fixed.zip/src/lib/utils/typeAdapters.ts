/**
 * Type adapters for converting between different data formats
 */

import { TikTokVideo as NewTikTokVideo } from '@/lib/types/tiktok';
import { TikTokVideo as LegacyTikTokVideo, TemplateSection } from '@/lib/types/trendingTemplate';

/**
 * Convert from legacy TikTokVideo format to new format
 */
export function convertToNewTikTokFormat(legacyVideo: LegacyTikTokVideo): NewTikTokVideo {
  return {
    id: legacyVideo.id,
    desc: legacyVideo.text,
    createTime: legacyVideo.createTime,
    author: {
      id: legacyVideo.authorMeta.id,
      uniqueId: legacyVideo.authorMeta.nickname,
      nickname: legacyVideo.authorMeta.name,
      avatarThumb: '',
      verified: legacyVideo.authorMeta.verified
    },
    stats: {
      diggCount: legacyVideo.stats.diggCount,
      shareCount: legacyVideo.stats.shareCount,
      commentCount: legacyVideo.stats.commentCount,
      playCount: legacyVideo.stats.playCount
    },
    video: {
      id: legacyVideo.id,
      duration: legacyVideo.videoMeta.duration,
      ratio: '16:9',
      cover: '',
      playAddr: legacyVideo.videoUrl,
      downloadAddr: '',
      height: legacyVideo.videoMeta.height,
      width: legacyVideo.videoMeta.width
    },
    hashtags: Array.isArray(legacyVideo.hashtags) 
      ? legacyVideo.hashtags.map(tag => ({
          id: '',
          name: typeof tag === 'string' ? tag : '',
          title: typeof tag === 'string' ? tag : ''
        }))
      : []
  };
}

/**
 * Convert from new TikTokVideo format to legacy format
 */
export function convertToLegacyTikTokFormat(newVideo: NewTikTokVideo): LegacyTikTokVideo {
  return {
    id: newVideo.id,
    text: newVideo.desc,
    createTime: newVideo.createTime,
    authorMeta: {
      id: newVideo.author.id,
      name: newVideo.author.nickname,
      nickname: newVideo.author.uniqueId,
      verified: newVideo.author.verified || false
    },
    videoMeta: {
      height: newVideo.video.height || 0,
      width: newVideo.video.width || 0,
      duration: newVideo.video.duration
    },
    hashtags: newVideo.hashtags?.map(tag => tag.name) || [],
    stats: {
      diggCount: newVideo.stats.diggCount,
      shareCount: newVideo.stats.shareCount,
      commentCount: newVideo.stats.commentCount,
      playCount: newVideo.stats.playCount
    },
    videoUrl: newVideo.video.playAddr || '',
    webVideoUrl: ''
  };
}

/**
 * Convert raw Apify data to our legacy TikTokVideo format
 * This is a more robust converter that handles various input formats
 */
export function convertRawToLegacyFormat(rawData: any): LegacyTikTokVideo {
  return {
    id: rawData.id || '',
    text: rawData.text || rawData.desc || '',
    createTime: rawData.createTime || Date.now(),
    authorMeta: {
      id: rawData.authorMeta?.id || rawData.author?.id || '',
      name: rawData.authorMeta?.name || rawData.author?.nickname || '',
      nickname: rawData.authorMeta?.nickname || rawData.author?.uniqueId || '',
      verified: rawData.authorMeta?.verified || rawData.author?.verified || false
    },
    videoMeta: {
      height: rawData.videoMeta?.height || rawData.video?.height || 0,
      width: rawData.videoMeta?.width || rawData.video?.width || 0,
      duration: rawData.videoMeta?.duration || rawData.video?.duration || 0
    },
    hashtags: Array.isArray(rawData.hashtags) 
      ? rawData.hashtags.map((tag: any) => typeof tag === 'string' ? tag : tag.name || '')
      : [],
    stats: {
      diggCount: rawData.stats?.diggCount || 0,
      shareCount: rawData.stats?.shareCount || 0,
      commentCount: rawData.stats?.commentCount || 0,
      playCount: rawData.stats?.playCount || 0
    },
    videoUrl: rawData.videoUrl || rawData.video?.playAddr || '',
    webVideoUrl: rawData.webVideoUrl || ''
  };
}

/**
 * Convert raw Apify data to our new TikTokVideo format
 */
export function convertRawToNewFormat(rawData: any): NewTikTokVideo {
  return {
    id: rawData.id || '',
    desc: rawData.text || rawData.desc || '',
    createTime: rawData.createTime || Date.now(),
    author: {
      id: rawData.authorMeta?.id || rawData.author?.id || '',
      uniqueId: rawData.authorMeta?.nickname || rawData.author?.uniqueId || '',
      nickname: rawData.authorMeta?.name || rawData.author?.nickname || '',
      avatarThumb: rawData.authorMeta?.avatar || rawData.author?.avatarThumb || '',
      verified: rawData.authorMeta?.verified || rawData.author?.verified || false
    },
    stats: {
      diggCount: rawData.stats?.diggCount || 0,
      shareCount: rawData.stats?.shareCount || 0,
      commentCount: rawData.stats?.commentCount || 0,
      playCount: rawData.stats?.playCount || 0
    },
    video: {
      id: rawData.id || '',
      duration: rawData.videoMeta?.duration || rawData.video?.duration || 0,
      ratio: rawData.videoMeta?.ratio || rawData.video?.ratio || '16:9',
      cover: rawData.covers?.default || rawData.video?.cover || '',
      playAddr: rawData.videoUrl || rawData.video?.playAddr || '',
      downloadAddr: rawData.downloadUrl || rawData.video?.downloadAddr || '',
      height: rawData.videoMeta?.height || rawData.video?.height || 0,
      width: rawData.videoMeta?.width || rawData.video?.width || 0
    },
    hashtags: Array.isArray(rawData.hashtags) 
      ? rawData.hashtags.map((tag: any) => ({
          id: tag.id || '',
          name: typeof tag === 'string' ? tag : tag.name || '',
          title: typeof tag === 'string' ? tag : tag.title || tag.name || ''
        }))
      : []
  };
} 