"use client";

/**
 * Component Import Resolver
 * 
 * This utility helps resolve component imports by providing fallbacks to compatibility components
 * when the original imports fail.
 */

import * as React from 'react';
import * as CompatibilityComponents from '@/components/ui/ui-compatibility';

// Log initialization message to make it clear when this module loads
console.info('[ImportResolver] Module loaded');

// Create a simple fallback Switch component
const FallbackSwitch = (props: React.HTMLAttributes<HTMLDivElement>) => {
  return React.createElement('div', {
    style: {
      width: '44px',
      height: '24px',
      borderRadius: '12px',
      backgroundColor: '#e5e7eb',
      position: 'relative',
      cursor: 'not-allowed',
      display: 'inline-block',
    },
    ...props
  }, 
  React.createElement('span', {
    style: {
      width: '20px',
      height: '20px',
      borderRadius: '10px',
      backgroundColor: '#ffffff',
      position: 'absolute',
      top: '2px',
      left: '2px',
      boxShadow: '0 1px 2px rgba(0, 0, 0, 0.1)',
    }
  }));
};

// Map of component names to their compatibility implementations
const componentMap: Record<string, any> = {
  // Card components
  Card: CompatibilityComponents.Card,
  CardHeader: CompatibilityComponents.CardHeader,
  CardFooter: CompatibilityComponents.CardFooter,
  CardTitle: CompatibilityComponents.CardTitle,
  CardDescription: CompatibilityComponents.CardDescription,
  CardContent: CompatibilityComponents.CardContent,
  
  // Form components
  Button: CompatibilityComponents.Button,
  Input: CompatibilityComponents.Input,
  Textarea: CompatibilityComponents.Textarea,
  Label: CompatibilityComponents.Label,
  
  // Data display components
  Badge: CompatibilityComponents.Badge,
  
  // Dialog components
  Dialog: CompatibilityComponents.Dialog,
  DialogTrigger: CompatibilityComponents.DialogTrigger,
  DialogContent: CompatibilityComponents.DialogContent,
  DialogHeader: CompatibilityComponents.DialogHeader,
  DialogFooter: CompatibilityComponents.DialogFooter,
  DialogTitle: CompatibilityComponents.DialogTitle,
  DialogDescription: CompatibilityComponents.DialogDescription,
  
  // Select components
  Select: CompatibilityComponents.Select,
  SelectTrigger: CompatibilityComponents.SelectTrigger,
  SelectValue: CompatibilityComponents.SelectValue,
  SelectContent: CompatibilityComponents.SelectContent,
  SelectItem: CompatibilityComponents.SelectItem,
  
  // Tooltip components
  Tooltip: CompatibilityComponents.Tooltip,
  TooltipTrigger: CompatibilityComponents.TooltipTrigger,
  TooltipContent: CompatibilityComponents.TooltipContent,
  TooltipProvider: CompatibilityComponents.TooltipProvider,
  
  // Switch component - not in compatibility components, so use our fallback
  Switch: FallbackSwitch,
};

/**
 * Create fallback component with a visual error state
 */
function createFallbackComponent(name: string) {
  return function FallbackComponent(props: any) {
    return React.createElement(
      'div',
      {
        style: {
          padding: '0.5rem',
          border: '1px dashed #f87171',
          borderRadius: '0.25rem',
          color: '#b91c1c',
          fontSize: '0.75rem',
          margin: '0.25rem 0',
          display: 'inline-block'
        },
        ...props,
      },
      `[${name}]`
    );
  };
}

/**
 * Safely resolve UI component imports - this is used to fix errors
 * when component imports fail
 * 
 * @param components Object containing imported components
 * @returns Object with resolved components (using compatibility versions if needed)
 */
export function resolveComponents(components: Record<string, any>): Record<string, any> {
  const resolvedComponents: Record<string, any> = {};
  
  // For each component in the import object
  for (const [name, component] of Object.entries(components)) {
    // If the component is undefined or not a valid component, use the compatibility version
    if (!component || typeof component !== 'function') {
      console.warn(`[ImportResolver] Component '${name}' is undefined or invalid, using compatibility version`);
      resolvedComponents[name] = componentMap[name] || createFallbackComponent(name);
    } else {
      // Otherwise use the original component
      resolvedComponents[name] = component;
    }
  }
  
  return resolvedComponents;
}

/**
 * Global error handler for component resolution - this is used as a last resort
 * to catch errors when trying to render undefined components
 */
export function handleComponentResolutionErrors() {
  if (typeof window !== 'undefined') {
    // Override React.createElement to catch undefined component errors
    const originalCreateElement = React.createElement;
    
    // Replace React.createElement with our version that handles undefined components
    (React as any).createElement = function(type: any, props: any, ...children: any[]) {
      // If the component type is undefined, replace it with a fallback
      if (type === undefined || type === null) {
        console.warn('[ImportResolver] Caught undefined component in React.createElement, using fallback div');
        return originalCreateElement('div', { 
          style: { 
            padding: '0.5rem', 
            border: '1px dashed #f87171',
            borderRadius: '0.25rem',
            color: '#b91c1c',
            fontSize: '0.75rem',
            margin: '0.25rem 0'
          },
          'data-error': 'undefined-component'
        }, '[Component Error]');
      }
      
      // Check if it's a string (HTML element) or a valid component
      if (typeof type === 'string' || typeof type === 'function' || typeof type === 'object') {
        // Proceed normally for valid components
        return originalCreateElement(type, props, ...children);
      }
      
      // If we get here, the component is invalid but not undefined
      console.warn(`[ImportResolver] Invalid component type: ${typeof type}`, type);
      return originalCreateElement('div', {
        style: {
          padding: '0.5rem',
          border: '1px dashed #f87171',
          borderRadius: '0.25rem',
          color: '#b91c1c',
          fontSize: '0.75rem',
          margin: '0.25rem 0'
        },
        'data-error': 'invalid-component'
      }, `[Invalid Component: ${typeof type}]`);
    };
    
    console.info('[ImportResolver] Component resolution error handler installed');
    
    return () => {
      // Restore original createElement when cleanup is needed
      (React as any).createElement = originalCreateElement;
      console.info('[ImportResolver] Component resolution error handler removed');
    };
  }
  
  return () => {}; // No-op for SSR
}

/**
 * Initialize the component resolution system
 * This should be called in a client component high in the component tree
 */
export function initializeComponentResolution() {
  if (typeof window !== 'undefined') {
    // Install the global error handler
    const cleanupHandler = handleComponentResolutionErrors();
    
    // Log initialization
    console.info('[ImportResolver] Component resolution system initialized');
    
    // Add window.fixComponents utility for debugging
    (window as any).fixComponents = () => {
      console.info('[ImportResolver] Manual component resolution triggered');
      handleComponentResolutionErrors();
    };
    
    return cleanupHandler;
  }
  
  return () => {}; // No-op for SSR
} 