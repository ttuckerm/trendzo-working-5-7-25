# Trendzo - AI-Powered Social Media Template Management

Trendzo is a comprehensive platform for managing, customizing, and tracking social media templates. It leverages AI to provide performance predictions, content optimization, and analytics for your social media content.

![Trendzo Logo](/public/images/logos/trendzo-full-logo.svg)

## Features

- **Template Library**: Access a vast collection of trending templates across various categories
- **AI-Powered Remixing**: Customize templates with AI-assisted suggestions
- **Performance Prediction**: Get AI predictions for how your content will perform
- **Analytics Dashboard**: Track performance of templates with detailed metrics
- **Newsletter Integration**: Generate shareable links with performance tracking
- **Expert vs. AI Comparison**: Compare AI-generated content with expert-created content
- **Video Analysis**: Extract templates from popular videos with automatic structure detection

## Tech Stack

- **Frontend**: Next.js 14 (App Router), React, TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes, Firebase (Firestore, Storage, Authentication)
- **AI**: OpenAI, Anthropic Claude, and custom AI pipelines
- **Authentication**: Firebase Auth with multiple providers
- **Analytics**: Custom analytics pipeline with Firebase

## Getting Started

### Prerequisites

- Node.js 18+
- npm or yarn
- Firebase project (for database and authentication)
- OpenAI API key (for AI features)
- Anthropic API key (for Claude integration)

### Installation

1. Clone the repository
```bash
git clone https://github.com/your-username/trendzo.git
cd trendzo
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables - create a `.env.local` file with:
```
# Firebase Configuration
NEXT_PUBLIC_FIREBASE_API_KEY=your_firebase_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_firebase_auth_domain
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_firebase_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_firebase_storage_bucket
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_firebase_messaging_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_firebase_app_id

# AI API Keys
OPENAI_API_KEY=your_openai_api_key
ANTHROPIC_API_KEY=your_anthropic_api_key

# Base URL for the application
NEXT_PUBLIC_BASE_URL=http://localhost:3000
```

4. Start the development server
```bash
npm run dev
```

5. Open [http://localhost:3000](http://localhost:3000) in your browser

## Testing

Trendzo includes a comprehensive testing suite built with Jest and React Testing Library.

### Running Tests

```bash
# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with coverage report
npm run test:coverage

# Run only component tests
npm run test:components
```

### Test Structure

Tests are organized in the `src/__tests__` directory:

- `components/`: Tests for UI components
- `hooks/`: Tests for custom React hooks
- `lib/`: Tests for utility functions and services

### Writing Tests

When adding new features, create corresponding tests following these patterns:

```typescript
// Example component test
import { render, screen } from '@testing-library/react';
import { MyComponent } from '@/components/MyComponent';

describe('MyComponent', () => {
  it('renders correctly', () => {
    render(<MyComponent prop="value" />);
    expect(screen.getByText('Expected Text')).toBeInTheDocument();
  });
});
```

## Development Workflow

### Project Structure

- `src/app`: Next.js App Router pages and layouts
  - `(dashboard)`: Dashboard-related pages (grouped route)
  - `api`: API routes
- `src/components`: Reusable React components
  - `ui`: UI primitives (buttons, cards, etc.)
  - `layout`: Layout components (header, sidebar, etc.)
- `src/lib`: Utility functions, services, and hooks
  - `contexts`: React context providers
  - `firebase`: Firebase configuration and utilities
  - `hooks`: Custom React hooks
  - `services`: Application services

### Code Style & Linting

- TypeScript for static type checking
- ESLint for code linting
- Prettier for code formatting

### Deployment

The application is configured for deployment on Vercel:

```bash
# Build for production
npm run build

# Preview production build locally
npm run start
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/my-feature`)
3. Commit your changes (`git commit -m 'feat(component): add my feature'`)
4. Push to the branch (`git push origin feature/my-feature`)
5. Create a Pull Request