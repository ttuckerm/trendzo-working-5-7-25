// Redirect script for admin-dashboard
if (typeof window !== 'undefined') {
  window.location.href = '/admin-dashboard.html';
} 